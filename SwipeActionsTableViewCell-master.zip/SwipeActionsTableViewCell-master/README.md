[Tutorial on how to add swipe actions to a UITableViewCell](https://programmingwithswift.com/uitableviewcell-swipe-actions-with-swift/)
