//
//  TwitterTests.swift
//  TwitterTests
//
//  Created by Francis Chan on 5/11/18.
//  Copyright © 2018 TheiPhoneBuddy. All rights reserved.
//

import XCTest
import HTTPManager

@testable import Twitter

class TwitterTests: XCTestCase {
    
    override func setUp() {
        super.setUp()
    }
    
    override func tearDown() {
        super.tearDown()
    }
    
    /* Test HTTPService Method(s) */
    /******** Happy Path *********/
    func testMakeRequest(){
        
        /* XCTestExpectation */
        let expectation = XCTestExpectation(description: "testMakeRequest")

        let page:Int = 1
        let searchTerm:String? = "Harry Potter"
        
        let http:HTTPService = HTTPService()
        http.getTitles(searchTerm,page: page) { (aryDataModel,page,total_pages,errorMsg) in
            
            if errorMsg == nil{
                /* XCTestExpectation */
                XCTAssertNotNil(aryDataModel, "Data downloaded.")
            }else{
                /* XCTestExpectation */
                XCTAssertNotNil(errorMsg, "No data was downloaded.")
            }
            
            /* XCTestExpectation */
            expectation.fulfill()
        }
        
        /* XCTestExpectation */
        wait(for: [expectation], timeout: 10.0)
    }
    
    func testGetImage(){
        
        /* XCTestExpectation */
        let expectation = XCTestExpectation(description: "testGetImage")

         var dataModel:DataModel = DataModel()
         dataModel.poster_path = "lR4drT4VGfts32j9jYTZUc1a3Pa.jpg"

        let http:HTTPService = HTTPService()
        http.getImage(dataModel.poster_path) { (image,errorMsg) in
            if errorMsg == nil {
                /* XCTestExpectation */
                XCTAssertNotNil(image, "Image downloaded.")
            }else{
                /* XCTestExpectation */
                XCTAssertNotNil(errorMsg, "No image was downloaded.")
            }
            
            /* XCTestExpectation */
            expectation.fulfill()
        }
        
        /* XCTestExpectation */
        wait(for: [expectation], timeout: 10.0)
    }
    
    /******** Not so Happy Path *********/
    func testMakeRequest2(){
        
        /* XCTestExpectation */
        let expectation = XCTestExpectation(description: "testMakeRequest2")
        
        let page:Int = 1
        
        /* Test 'searchTerm' equal to nil. Make sure the app does not crash!
         */
        let searchTerm:String? = nil
        
        let http:HTTPService = HTTPService()
        http.getTitles(searchTerm,page: page) { (aryDataModel,page,total_pages,errorMsg) in
            
            if errorMsg == nil{
                /* XCTestExpectation */
                XCTAssertNotNil(aryDataModel, "Data downloaded.")
            }else{
                /* XCTestExpectation */
                XCTAssertNotNil(errorMsg, "No data was downloaded.")
            }
            
            /* XCTestExpectation */
            expectation.fulfill()
        }
        
        /* XCTestExpectation */
        wait(for: [expectation], timeout: 10.0)
    }

    func testGetImage2(){
        
        /* XCTestExpectation */
        let expectation = XCTestExpectation(description: "testGetImage2")
        
        var dataModel:DataModel = DataModel()
        dataModel.poster_path = "lR4drT4VGfts32j9jYTZUc1a3Pa.jpg"
        
        /* Test 'poster_path' equal to nil. Make sure the app does not crash!
         */
        let poster_path:String? = nil
        
        let http:HTTPService = HTTPService()
        http.getImage(poster_path) { (image,errorMsg) in
            if errorMsg == nil {
                /* XCTestExpectation */
                XCTAssertNotNil(image, "Image downloaded.")
            }else{
                /* XCTestExpectation */
                XCTAssertNotNil(errorMsg, "No image was downloaded.")
            }
            
            /* XCTestExpectation */
            expectation.fulfill()
        }
        
        /* XCTestExpectation */
        wait(for: [expectation], timeout: 10.0)
    }
}
