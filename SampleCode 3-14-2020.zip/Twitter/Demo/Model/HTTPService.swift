//
//  HTTPService.swift
//  Test
//
//  Created by Francis Chan on 5/11/18.
//  Copyright © 2018 TheiPhoneBuddy. All rights reserved.
//

import UIKit
import CommonUtils
import HTTPManager

class HTTPService: NSObject {
    
    /* Public Method(s) */
    func getTitles(_ searchTerm:String?,
                   page:Int?,
                    completion:@escaping(_ aryDataModel:Array<DataModel>?,
                                         _ page:Int?,
                                         _ total_pages:Int?,
                                         _ errorMsg:String?) -> Void) {
        
        if searchTerm == nil {
            completion(nil,nil,nil,"'searchTerm' param cannot be nil!")
            return
        }
        
        let obj:CommonUtils = CommonUtils()
        let urlString:String? = ApiKeyManager.searchUrl + ApiKeyManager.getKey() + "&query=" + obj.encodeURL(searchTerm)! + "&page=" + String(page!)
        let request: [String: String] = ["urlString": urlString!,
                                         "requestID":""]
        
        /*
         "HTTPManager.framework" is a free dynamic network library I developed in swift
         and can be downloaded from my GitHub acct. at:
         
         https://github.com/TheiPhoneBuddy/HTTPManager
         
         "FastFoodApp","TheDailyNewsApp","TheiPhoneBuddy" and other apps use this library that
          are currently in production e.g. App Store.
         */
        HTTPManager.getData(request,
                            callback:{(resp:Dictionary<String,Any>?,
                            errorMsg:String?) -> Void in

            if((errorMsg) != nil){
                completion(nil,nil,nil,errorMsg)
            }else{
                
                var aryDataModel:Array<DataModel>? = []

                let resp:Dictionary<String,Any>? = resp?["responseDict"] as? Dictionary<String, Any>
                let results:Array<Dictionary<String,Any>>? = resp?["results"] as? Array<Dictionary<String,Any>>

                var page:Int = 0
                var total_pages:Int = 0

                /* page */
                if resp?["page"] != nil {
                    page = resp?["page"] as! Int
                }
            
                /* total_pages */
                if resp?["total_pages"] != nil {
                    total_pages = resp?["total_pages"] as! Int
                }

                for dict in results! {
                    
                    autoreleasepool{
                        var dataModel:DataModel? = DataModel()
                        
                        /* idValue */
                        let idValue:Int? = dict["id"] as? Int
                        if idValue != nil {
                            dataModel?.idValue = idValue!
                        }
                        
                        /* title */
                        let title:String? = dict["title"] as? String
                        if title != nil {
                            dataModel?.title = title!
                        }
                        
                        /* poster_path */
                        let poster_path:String? = dict["poster_path"] as? String
                        if poster_path != nil {
                            dataModel?.poster_path = poster_path!
                        }
                        
                        /* overview */
                        let overview:String? = dict["overview"] as? String
                        if overview != nil {
                            dataModel?.overview = overview!
                        }
                        
                        /* adult */
                        let adult:Bool? = dict["adult"] as? Bool
                        if adult != nil {
                            dataModel?.adult = adult!
                        }
                        
                        aryDataModel?.append(dataModel!)
                        dataModel = nil
                    }
                }
                
                if aryDataModel?.count == 0 {
                    completion(nil,nil,nil,"No records returned!")
                }else{
                    aryDataModel = aryDataModel?.sorted(by: { $0.title < $1.title })
                    completion(aryDataModel,page,total_pages,nil)
                }
            }//if
                                
        })//HTTPManager
    }
    
    func getImage(_ poster_path:String?,
                   completion:@escaping(_ image:UIImage?,
                   _ errorMsg:String?) -> Void) {

        if poster_path == nil {
            completion(nil,"'poster_path' param cannot be nil!")
            return
        }
        
        let urlString:String? = ApiKeyManager.photoUrl + poster_path!
        let request: [String: String] = ["urlString": urlString!,
                                         "requestID":""]
        
        HTTPManager.getData(request,callback:{(resp:Dictionary<String,Any>?,errorMsg:String?) -> Void in
            if((errorMsg) != nil){
                completion(nil,errorMsg)
            }else{
                let data:Data? = resp?["responseData"] as? Data
                if let tmp = data {
                    let image:UIImage = UIImage(data: tmp)!
                    completion(image,nil)
                }else{
                    completion(nil,"Failed to return image data from 'HTTPManager'.")
                }
            }
        })
    }
    
    /* Private Method(s) */    
    deinit {
        print("HTTPService:deinit")
    }
}
