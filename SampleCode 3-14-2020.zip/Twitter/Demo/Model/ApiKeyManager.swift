//
//  ApiKeyManager.swift
//  Demo
//
//  Created by Francis Chan on 5/11/18.
//  Copyright © 2018 TheiPhoneBuddy. All rights reserved.
//

import UIKit

class ApiKeyManager: NSObject {
    
    /* URL(s) */
    static var searchUrl:String = "https://api.themoviedb.org/3/search/movie?api_key="
    static var photoUrl:String = "https://image.tmdb.org/t/p/w600_and_h900_bestv2/"

    /* Key(s) */
    static fileprivate let key:String = "2a61185ef6a27f400fd92820ad9e8537"

    static func getKey() -> String {
        return key
    }
}
