//
//  DataModel.swift
//  Demo
//
//  Created by Francis Chan on 5/11/18.
//  Copyright © 2018 TheiPhoneBuddy. All rights reserved.
//

import UIKit

struct DataModel {
    var idValue:Int = 0
    var title:String = ""
    var poster_path:String = ""
    var overview:String = ""
    var adult:Bool = false
}
