//
//  DemoViewController.swift
//  Demo
//
//  Created by Francis Chan on 5/11/18.
//  Copyright © 2018 TheiPhoneBuddy. All rights reserved.
//

import UIKit

class DemoViewController: BaseTableViewController {

    @IBOutlet weak var customFooter: CustomFooter!

    /* View Life Cycle Method(s) */
    override func viewDidLoad() {
        super.viewDidLoad()
        tableView.estimatedRowHeight = 94.0
        tableView.rowHeight = UITableView.automaticDimension
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    /* TableView Method(s) */
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return aryData.count
    }
    
    override func tableView(_ tableView: UITableView,
                            cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let identifierFromStoryboard:String = "CustomCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: identifierFromStoryboard, for: indexPath) as! CustomCell
        
        let data:DataModel = aryData[indexPath.row] as DataModel
        
        cell.title.text = data.title
        
        cell.overview.text = data.overview
        
        getImage(indexPath, cell:cell)

        return cell
    }
}

extension DemoViewController{
    /* Search Bar */
    func searchBarSearchButtonClicked(_ searchBar: UISearchBar) {
        dismissKeyboard()
        
        if !searchBar.text!.isEmpty {
            if (searchBar.text?.count)! > 2 {
                searchTerm = searchBar.text!
                makeRequest()
            }
        }
    }
    
    /* UISearchBarDelegate Method(s) */
    @objc func dismissKeyboard() {
        searchBar.resignFirstResponder()
    }
}
