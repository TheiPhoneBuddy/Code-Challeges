//
//  BaseTableViewController.swift
//  Twitter
//
//  Created by Francis Chan on 5/11/18.
//  Copyright © 2018 TheiPhoneBuddy. All rights reserved.
//

import UIKit
import CommonUtils

class BaseTableViewController: UITableViewController,
                               UISearchBarDelegate {
    
    /* IBOutLets */
    @IBOutlet weak var searchBar: UISearchBar!

    /* Store downloaded images */
    var images: Dictionary<String,Any> = [:]
    
    /* Array of DataModel objects */
    var aryData:Array<DataModel> = []

    /* poster_path */
    var poster_path:String = "default.png"

    /* searchTerm */
    var searchTerm:String? = "Planet of the Apes"

    /* page */
    var page:Int? = 0
    var total_pages:Int? = 0
    var loading = false

    /* detailData */
    var detailData:DataModel? = nil
    
    /* HTTP Method(s) */
    func makeRequest(){
        weak var weakSelf = self
        let http:HTTPService = HTTPService()
        http.getTitles(searchTerm,page: page) { (aryDataModel,page,total_pages,errorMsg) in
            if errorMsg != nil{
                CommonUtils.displayAlert("", message: errorMsg!,vc:self)
            }else{
                DispatchQueue.main.async {
                    self.page = page
                    self.total_pages = total_pages
                    
                    weakSelf?.aryData = aryDataModel!
                    weakSelf?.tableView.reloadData()
                }
            }
        }
    }
    
    func getImage(_ indexPath: IndexPath, cell: CustomCell) {

        /* Set Default Image */
        cell.poster_path.image = UIImage(named: "default")
        
        /* current row */
        let dataModel:DataModel = aryData[indexPath.row] as DataModel
        
        /* requestID */
        let requestID:String? = String(dataModel.idValue)
        if requestID == nil {
            return
        }
        
        /* dataModel.poster_path */
        if dataModel.poster_path == "" {
            return
        }

        /* urlString */
        let urlString:String? = ApiKeyManager.photoUrl + dataModel.poster_path
        if urlString == nil {
            return
        }

        /* Check images dictionary */
        if self.images[requestID!] != nil {
            DispatchQueue.main.async {
                let image:UIImage = self.images[requestID!] as! UIImage
                cell.poster_path.image = image
            }
            return
        }

        weak var weakSelf = self
        let http:HTTPService = HTTPService()
        http.getImage(dataModel.poster_path) { (image,errorMsg) in
            if errorMsg == nil {
                DispatchQueue.main.async {
                    weakSelf?.images[requestID!] = image
                    cell.poster_path.image = image
                    print("\(requestID!) - \(urlString!)")
                }
            }else{
                /* Do not show error here because images are continously being downloaded.
                   The "showDialog" displays a modal alert!
                 */
                print(errorMsg!)
            }
        }
    }
    
    /* View Life Cycle Method(s) */
    override func viewDidLoad() {
        super.viewDidLoad()
        searchBar.text = searchTerm
        self.page = 1
        makeRequest()
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        /* Clear images cache. */
        self.images.removeAll()
    }
    
    /* Helper Method(s) */
    override func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let currentOffset = scrollView.contentOffset.y
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        
        if (maximumOffset - currentOffset) <= 40 {
            //makeRequest()
        }
    }
}
