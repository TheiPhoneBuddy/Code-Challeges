//
//  CustomFooter.swift
//  Twitter
//
//  Created by Francis Chan on 5/12/18.
//  Copyright © 2018 TheiPhoneBuddy. All rights reserved.
//

import UIKit

class CustomFooter: UIView {
    
    @IBOutlet var activityIndicator: UIActivityIndicatorView!
    @IBOutlet var msg: UILabel!
    
    override func awakeFromNib() {
        self.activityIndicator.startAnimating()
    }
}
