//
//  Card.h
//
//  Created by Francis Chan on 6/29/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    Hearts,
    Spades,
    Diamonds,
    Clubs
} Suit;

@interface Card : NSObject

@property(nonatomic,assign) NSInteger cardNumber;
@property(nonatomic,assign) Suit suit;
@property(nonatomic,assign) BOOL cardClosed;

-(id) initWithCardNumber:(NSInteger) aCardNumber suit:(Suit) aSuit;
-(NSInteger) getValue;
@end
