//
//  Card.m
//  BlackJack
//
//  Created by Francis Chan on 6/29/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

#import "Card.h"

@implementation Card

-(id) initWithCardNumber:(NSInteger)aCardNumber suit:(Suit)aSuit {
    if (self = [super init])
    {
        self.suit = aSuit;
        self.cardNumber = aCardNumber;
        self.cardClosed = NO;
    }
    return self;
}

-(NSInteger) getValue {
    if (self.cardClosed==YES)
    {
        return (0);
    }
    else if (self.cardNumber>=10)
        return (10);
    else if (self.cardNumber==1)
        return (11);
    else
        return (self.cardNumber);
}

-(NSString *) suitAsString{
    switch (self.suit) {
        case Hearts:
            return @"Heart";
            break;
        case Spades:
            return @"Spade";
            break;
        case Diamonds:
            return @"Diamond";
            break;
        case Clubs:
            return @"Club";
            break;
        default:
            return nil;
            break;
    }
}

-(NSString *) cardNumberAsString{
    switch (self.cardNumber) {
        case 1:
            return @"Ace";
            break;
        case 11:
            return @"Jack";
            break;
        case 12:
            return @"Queen";
            break;
        case 13:
            return @"King";
            break;
        default:
            return [NSString stringWithFormat:@"%ld", (long)self.cardNumber];
            break;
    }
}

-(NSString *) description {
    return [NSString stringWithFormat:@"%@ of %@",[self cardNumberAsString],
            [self suitAsString]];
}
@end
