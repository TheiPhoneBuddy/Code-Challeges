//
//  BlackjackModel.h
//
//  Created by Francis Chan on 6/29/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Deck.h"
#import "Hand.h"

typedef enum {
    Player,
    Dealer,
    Draw
} Winner;

@interface BlackjackModel : NSObject

@property(nonatomic,strong) Hand *dealerHand;
@property(nonatomic,strong) Hand *playerHand;
@property(nonatomic,strong) Deck *deck;
@property(nonatomic,assign) int totalPlays;
@property(nonatomic,assign) NSInteger numberOfDealerWins;
@property(nonatomic,assign) NSInteger numberOfPlayerWins;

-(void) setup;
-(void) resetGame;
-(void) playerHandDraws;
-(void) playerStands;

+(BlackjackModel *)singleton;

@end
