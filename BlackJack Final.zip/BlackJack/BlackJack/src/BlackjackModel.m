//
//  BlackjackModel.m
//
//  Created by Francis Chan on 6/29/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

#import "BlackjackModel.h"

@implementation BlackjackModel

static BlackjackModel* blackjackModel = nil;

-(id) init {
    if ((self = [super init])){
        self.deck = [[Deck alloc] init];
        self.playerHand = [[Hand alloc] init];
        self.dealerHand = [[Hand alloc] init];
        self.dealerHand.handClosed = YES;
        self.totalPlays = 0;
    }
    return (self);
}

-(void)setup{
    [self playerHandDraws];
    [self dealerHandDraws];
    
    [self playerHandDraws];
    [self dealerHandDraws];
}

-(void)dealerHandDraws{
    [self.dealerHand addCard:[self.deck drawCard]];
}

-(void)playerHandDraws{
    [self.playerHand addCard:[self.deck drawCard]];
    [self EndGameIfPlayerIsBust];
}

-(void)dealerStartsTurn{
    [self.dealerHand setHandClosed:NO];
}

-(void)playerStands{
    [self dealerStartsTurn];
    [self dealerPlays];
}

-(void) EndGameIfPlayerIsBust{
    if (self.playerHand.getValue > 21){
        self.numberOfDealerWins++;
        [self.dealerHand description];
        [self.playerHand description];
        NSLog(@"dealer:%@",self.dealerHand);
        NSLog(@"player:%@",self.playerHand);
        NSLog(@"*Dealer Wins, player busted!*");
        [self displayCurrentHand];
        [self gameEnds:Dealer];
        [self resetGame];
    }
}

-(void) gameEnds:(Winner) winner;{
    self.totalPlays = self.totalPlays+1;
    
    NSLog(@"numberOfDealerWins:%ld",self.numberOfDealerWins);
    NSLog(@"numberOfPlayerWins:%ld",self.numberOfPlayerWins);
    NSLog(@"totalPlays:%d",self.totalPlays);
}

-(void) resetGame;{
    NSLog(@"\n\n\n");
    NSLog(@"*New Game*");
    if(self.totalPlays > 5 ){
        NSLog(@"Deck Reset");
        self.totalPlays = 0;
        self.deck = nil;
        self.deck = [[Deck alloc] init];
    }
    
    self.playerHand = nil;
    self.dealerHand = nil;
    self.playerHand = [[Hand alloc] init];
    self.dealerHand = [[Hand alloc] init];
    self.dealerHand.handClosed = YES;

    [self setup];
}

-(void)displayCurrentHand{
    NSLog(@"\n\n");
    NSLog(@"Dealer:%ld",self.dealerHand.getValue);
    NSLog(@"Player:%ld",self.playerHand.getValue);
}

-(void)dealerPlays{
    while (self.dealerHand.getValue < 17){
        [self dealerHandDraws];
    }
    
    [self displayCurrentHand];
    NSLog(@"dealer:%@",self.dealerHand);
    NSLog(@"player:%@",self.playerHand);
    if (self.dealerHand.getValue > 21){
        self.numberOfPlayerWins++;
        [self gameEnds:Player ];
        NSLog(@"*Player Wins! Dealer busted!*");

    }else if (self.dealerHand.getValue > self.playerHand.getValue){
        self.numberOfDealerWins++;
        [self gameEnds:Dealer];
        NSLog(@"*Dealer Wins!*");

    }else if (self.dealerHand.getValue < self.playerHand.getValue){
        self.numberOfPlayerWins++;
        [self gameEnds:Player];
        NSLog(@"*Player Wins!*");

    }else{
        NSLog(@"*Draw!*");
        [self gameEnds:Draw];
    }
    NSLog(@"\n\n");
}

+ (BlackjackModel *)singleton{
    if (blackjackModel == nil){
        blackjackModel = [[BlackjackModel alloc] init];
    }
    
    return blackjackModel;
}
@end
