//
//  Deck.m
//  BlackJack
//
//  Created by Francis Chan on 6/29/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

#import "Deck.h"
#import "Card.h"

@implementation Deck

-(id) init {
    if (self = [super init])
    {
        self.cards = [[NSMutableArray alloc] init];
        
        for (int suit = 0; suit <= 3; suit++)
        {
            for (int cardNumber = 1; cardNumber <= 13; cardNumber++)
            {
                [self.cards addObject:[[Card alloc] initWithCardNumber:cardNumber suit:suit]];
            }
        }
        
        [self shuffle];
    }
    return self;
}

-(Card *) drawCard {
    if ([self.cards count]>0)
    {
        Card* tCard = [self.cards lastObject];
        [self.cards removeLastObject];
        return tCard;
    }
    return nil;
}

-(void) shuffle {
    NSUInteger count = [self.cards count];
    for (NSUInteger i = 0; i < count; ++i) {
        NSInteger nElements = count - i;
        NSInteger n = (arc4random() % nElements) + i;
        [self.cards exchangeObjectAtIndex:i withObjectAtIndex:n];
    }
}

- (NSString *)description{
    return [NSString stringWithFormat:@"Deck : %@", self.cards];
}
@end
