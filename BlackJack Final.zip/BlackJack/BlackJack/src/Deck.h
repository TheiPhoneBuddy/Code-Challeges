//
//  Deck.h
//
//  Created by Francis Chan on 6/29/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

#import <Foundation/Foundation.h>

@class Card;
@interface Deck : NSObject

@property(nonatomic,strong)NSMutableArray *cards;

-(Card *) drawCard;
-(void) shuffle;

@end
