//
//  Hand.h
//
//  Created by Francis Chan on 6/29/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

#import <Foundation/Foundation.h>
@class Card;

@interface Hand : NSObject {
}

@property NSMutableArray *cardsInHand;
@property BOOL handClosed;

-(void) addCard:(Card *)card;
-(NSInteger) getValue;
-(NSInteger) countCards;
-(Card *) getCardAtIndex:(NSInteger) index;

@end
