//
//  main.m
//  BlackJack
//
//  Created by Francis Chan on 6/29/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BlackjackModel.h"
#import "Hand.h"
#import "Deck.h"
#import "Card.h"

int main(int argc, const char * argv[]) {

    @autoreleasepool {
        char choice;
        [[BlackjackModel singleton] setup];
        
        NSString *dealer;
        NSString *player;

        while(YES){
            newGame:
     
            dealer=[BlackjackModel singleton].dealerHand.description;
            player=[BlackjackModel singleton].playerHand.description;

            NSLog(@"dealer:%@",dealer);
            NSLog(@"player:%@",player);

            NSLog(@"\n\nSelect:\n1 hitMe\n2 stand\nx Exit");
            scanf(" %c",&choice);
            if (choice=='1'){
                 [[BlackjackModel singleton] playerHandDraws];
                goto newGame;
            } else if(choice=='2'){
                [[BlackjackModel singleton] playerStands];
                [[BlackjackModel singleton] resetGame];
                 goto newGame;
            } else if(choice=='x'){
                return 0;
            }else{
                NSLog(@"Invalid entry!");
                goto newGame;
            }
        }
        
    return 0;

    }//@autoreleasepool
}
