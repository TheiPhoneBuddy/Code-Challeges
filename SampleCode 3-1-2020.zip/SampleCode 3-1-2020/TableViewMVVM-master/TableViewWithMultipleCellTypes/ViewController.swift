//
//  ViewController.swift
//  StubHub
//
//  Created by Stanislav Ostrovskiy on 4/25/17.
//  Copyright © 2017 Stanislav Ostrovskiy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    fileprivate let viewModel = ProfileViewModel()
    
    @IBOutlet weak var tableView: UITableView?
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView?.dataSource = self.viewModel
        
        self.tableView?.estimatedRowHeight = 100
        self.tableView?.rowHeight = UITableView.automaticDimension
        
        self.tableView?.register(AboutCell.nib, forCellReuseIdentifier: AboutCell.identifier)
        self.tableView?.register(NamePictureCell.nib, forCellReuseIdentifier: NamePictureCell.identifier)
        self.tableView?.register(FriendCell.nib, forCellReuseIdentifier: FriendCell.identifier)
        self.tableView?.register(AttributeCell.nib, forCellReuseIdentifier: AttributeCell.identifier)
        self.tableView?.register(EmailCell.nib, forCellReuseIdentifier: EmailCell.identifier)
    }
}
