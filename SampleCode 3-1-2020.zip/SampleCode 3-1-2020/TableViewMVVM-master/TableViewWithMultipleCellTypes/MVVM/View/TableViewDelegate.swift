//
//  TableViewDelegate.swift
//  StubHub
//
//  Created by Francis Chan on 2/15/20.
//  
//

import UIKit

class TableViewDelegate: NSObject, UITableViewDelegate {
    // #1
    weak private var delegate: ViewController2Delegate?
    
    // #2
    init(withDelegate delegate: ViewController2Delegate) {
        self.delegate = delegate
    }
    
    // #3
    func tableView(_ tableView: UITableView,
                   didSelectRowAt indexPath: IndexPath) {
        self.delegate?.selectedCell(row: indexPath.row)
    }
}
