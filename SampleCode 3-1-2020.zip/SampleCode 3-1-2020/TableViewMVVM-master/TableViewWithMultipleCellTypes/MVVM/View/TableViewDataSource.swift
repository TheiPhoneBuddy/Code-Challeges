//
//  TableViewDataSource.swift
//  StubHub
//
//  Created by Francis Chan on 2/15/20.
//  
//

import UIKit

class TableViewDataSource: NSObject,UITableViewDataSource {
    var data = [String]()
    
    init(withData data: [String]) {
        self.data = data
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.data.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = UITableViewCell()
        cell.textLabel?.text = self.data[indexPath.row]
        
        return cell
    }
}
