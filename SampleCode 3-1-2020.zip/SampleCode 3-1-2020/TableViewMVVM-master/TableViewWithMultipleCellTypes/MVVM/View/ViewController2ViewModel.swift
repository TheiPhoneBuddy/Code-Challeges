//
//  ViewController2ViewModel.swift
//  StubHub
//
//  Created by Francis Chan on 2/16/20.
//  
//

import Foundation

class ViewController2ViewModel: NSObject {
    var sampleData: [String] = ["data 1",
                               "data 2",
                               "data 3",
                               "data 4",
                               "data 5"]
    
    var data: [String] {
      get { return sampleData}
    }
}
