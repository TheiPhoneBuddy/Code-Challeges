//
//  ViewController2.swift
//  StubHub
//
//  Created by Francis Chan on 2/15/20.
//  
//

import UIKit

class ViewController2: UIViewController,
                       ViewController2Delegate {
    
    var viewModel: ViewController2ViewModel = ViewController2ViewModel()
    var tableViewDatasource: TableViewDataSource?
    var tableViewDelegate: TableViewDelegate?
    
    @IBOutlet weak var tableView: UITableView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        initTableView()
     }
    
    func initTableView(){
        self.tableViewDelegate = TableViewDelegate(withDelegate: self)
        self.tableViewDatasource = TableViewDataSource(withData:viewModel.data)

        self.tableView.delegate = self.tableViewDelegate
        self.tableView.dataSource = self.tableViewDatasource
    }
    
    func selectedCell(row: Int) {
        print("Row: \(row)")
    }
}
