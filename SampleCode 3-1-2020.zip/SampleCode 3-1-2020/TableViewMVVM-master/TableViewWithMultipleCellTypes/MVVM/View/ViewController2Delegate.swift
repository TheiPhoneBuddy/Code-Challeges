//
//  ViewController2Delegate.swift
//  StubHub
//
//  Created by Francis Chan on 2/15/20.
//  
//

import UIKit

protocol ViewController2Delegate: class {
    func selectedCell(row: Int)
}
