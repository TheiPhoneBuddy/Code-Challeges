//
//  RxSwiftViewController.swift
//  TableViewWithMultipleCellTypes
//
//  Created by Francis Chan on 3/1/20.
//  Copyright © 2020 Stanislav Ostrovskiy. All rights reserved.
//

import UIKit
//import RxSwift

class RxSwiftViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        
//        // Observe sequence of Data
//        let observableOfSequence = Observable.of("Ronaldo", "Messi", "Neymar")observabl5.subscribe(onNext: { (str) in
//        print(str)
//        }, onError: { (error) in
//        print("I will execute if any error Occurs")
//        }, onCompleted: {
//        print("Completed Successfully")
//        })
        
    }
}
