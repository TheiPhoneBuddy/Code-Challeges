//
//  LoyaltyCardAwarenessViewModel.swift
//  StubHub
//
//  Created by Francis Chan on 2/15/20.
//  
//

import Foundation

class LoyaltyCardAwarenessViewModel: NSObject {
    var modelData: LoyaltyCardModel {
        get {
            var model:LoyaltyCardModel = LoyaltyCardModel()
                model.aryCellTypes = [LoyaltyCellType.HeaderTableViewCell,
                                      LoyaltyCellType.ProgressBarTableViewCell,
                                      LoyaltyCellType.ButtonTableViewCell]
                model.headerText = "Hi, Jimmy!"
                model.subText = "You're StubHub Gold."
                model.tierText = "tierText"
                model.buttonText = "Claim your points"

                return model
        }
    }
}
