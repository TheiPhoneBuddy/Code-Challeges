//
//  LoyaltyCardTableViewDataSource.swift
//  StubHub
//
//  Created by Francis Chan on 2/16/20.
//  
//

import UIKit

class LoyaltyCardTableViewDataSource: NSObject,
                                      UITableViewDataSource {
    var modelData: LoyaltyCardModel = LoyaltyCardModel()

    init(withModelData modelData: LoyaltyCardModel) {
        self.modelData = modelData
    }

    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return self.modelData.aryCellTypes.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let cellType:LoyaltyCellType = self.modelData.aryCellTypes[indexPath.row]
        
        switch cellType {
        case LoyaltyCellType.HeaderTableViewCell:
            if let cell = tableView.dequeueReusableCell(withIdentifier: LoyaltyHeaderTableViewCell.identifier, for: indexPath) as? LoyaltyHeaderTableViewCell {
                return cell
            }

        case LoyaltyCellType.ProgressBarTableViewCell:
            if let cell = tableView.dequeueReusableCell(withIdentifier: LoyaltyProgressTableViewCell.identifier, for: indexPath) as? LoyaltyProgressTableViewCell {
                return cell
            }

        case LoyaltyCellType.ButtonTableViewCell:
            if let cell = tableView.dequeueReusableCell(withIdentifier: LoyaltyButtonTableViewCell.identifier, for: indexPath) as? LoyaltyButtonTableViewCell {
                return cell
            }

        case LoyaltyCellType.ProgressCircleTableViewCell:
            if let cell = tableView.dequeueReusableCell(withIdentifier: Loyalty2CircleGraphsTableViewCell.identifier, for: indexPath) as? Loyalty2CircleGraphsTableViewCell {
                return cell
            }
            
        case LoyaltyCellType.ZeroStateTableViewCell:
            if let cell = tableView.dequeueReusableCell(withIdentifier: LoyaltyZeroStateTableViewCell.identifier, for: indexPath) as? LoyaltyZeroStateTableViewCell {
                return cell
            }
        }

        print(modelData.headerText,modelData.subText,self.modelData.aryCellTypes)
        return UITableViewCell()
    }
}
