//
//  LoyaltyCardTableViewDelegate.swift
//  StubHub
//
//  Created by Francis Chan on 2/16/20.
//  
//

import UIKit

class LoyaltyCardTableViewDelegate: NSObject, UITableViewDelegate {
    weak private var delegate: LoyaltyCardDelegate?
    
    init(withDelegate delegate: LoyaltyCardDelegate) {
        self.delegate = delegate
    }
    func tableView(_ tableView: UITableView,
                   didSelectRowAt indexPath: IndexPath) {
        self.delegate?.selectedCell(row: indexPath.row)
    }
}
