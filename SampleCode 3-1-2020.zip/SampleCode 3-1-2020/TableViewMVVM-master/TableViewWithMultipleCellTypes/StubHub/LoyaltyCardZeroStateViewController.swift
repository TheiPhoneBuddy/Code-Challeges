//
//  LoyaltyCardZeroStateViewController.swift
//
//
//  Created by Francis Chan on 2/16/20.
//  
//

import UIKit

class LoyaltyCardZeroStateViewController: LoyaltyViewControllerBase,
                                          LoyaltyCardDelegate {

    var viewModel: LoyaltyCardZeroStateViewModel = LoyaltyCardZeroStateViewModel()
    var tableViewDatasource: LoyaltyCardTableViewDataSource?
    var tableViewDelegate: LoyaltyCardTableViewDelegate?

    private func initTableView(){
        self.tableViewDelegate = LoyaltyCardTableViewDelegate(withDelegate: self)
        self.tableViewDatasource = LoyaltyCardTableViewDataSource(withModelData: viewModel.modelData)

        tableViewObject.delegate = self.tableViewDelegate
        tableViewObject.dataSource = self.tableViewDatasource

        //Register cells used by "ZeroState" card only.
         tableViewObject.register(LoyaltyZeroStateTableViewCell.nib, forCellReuseIdentifier: LoyaltyZeroStateTableViewCell.identifier)
    }

    //Delegate Method(s)
    func selectedCell(row: Int) {
        print("Row: \(row)")
    }

    //View Life Cycle Method(s)
    override func viewDidLoad() {
        super.viewDidLoad()
        initTableView()
    }
}
