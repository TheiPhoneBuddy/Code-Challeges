//
//  NumbersViewController.swift
//  RxExample
//
//  Created by Krunoslav Zaher on 12/6/15.
//  Copyright © 2015 Krunoslav Zaher. All rights reserved.
//
/*
 https://guides.cocoapods.org/using/using-cocoapods.html
 
 https://github.com/dzungnguyen1993/GraphQLExample
 https://github.com/ReactiveX/RxSwift
 https://blog.usejournal.com/reactive-extension-in-swift-with-sample-app-4f4a748b5c8f
 https://medium.com/@kishannakum/reactive-programming-in-swift-part-1-48bfc9062d1b
 https://medium.com/swift-programming/reactive-swift-3b6050375534
 https://hub.packtpub.com/reactive-programming-in-swift-with-rxswift-and-rxcocoa-tutorial/
 
 SpaceXPedia-master
 ConferencePlanner
 frontpage-ios-app
 frontpage-server
 fullstack-tutorial
 starwars-server
 
 
 
 
 
 */
import UIKit
import RxSwift
import RxCocoa

class NumbersViewController: ViewController {
    @IBOutlet weak var number1: UITextField!
    @IBOutlet weak var number2: UITextField!
    @IBOutlet weak var number3: UITextField!

    @IBOutlet weak var result: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
        //original()
        
        //test1()
        //test2()
        test3()
    }
    
    func test1(){
        let disposeBag = DisposeBag()
        
        let observablOfArray = Observable.of(["Ronaldo", "Messi", "Neymar"])
        observablOfArray.subscribe(onNext: { (arr) in
              print(arr)
        }, onError: { (error) in
          print("I will execute if any error Occurs")
        }, onCompleted: {
           print("Completed Successfully")
        }).disposed(by: disposeBag)
    }
    
    func test2(){
        let aDisposableBag = DisposeBag()
        
        let thisIsAnObservableStream = Observable.from([1, 2, 3, 4, 5, 6])
        let subscription = thisIsAnObservableStream.subscribe(
        onNext: {
            print("Next value: \($0)") },
        onError: {
            print("Error: \($0)") },
        onCompleted: {
            print("Completed")
        })

        // add the subscription to the disposable bag
        // when the bag is collected, the subscription is disposed
        subscription.disposed(by: aDisposableBag)
        // if you do not use a disposable bag, do not forget this!
        // subscription.dispose()
    }
    
    func test3(){
        let aDisposableBag = DisposeBag()
        
        let thisIsAnObservableStream: Observable = Observable.from([1, 2, 3, 4, 5, 6])
           .observeOn(MainScheduler.instance).map { n in
              print("This is performed on the main scheduler")
           }
        
        let subscription = thisIsAnObservableStream
        .subscribeOn(ConcurrentDispatchQueueScheduler(qos: .background))
        .subscribe(onNext: { event in
        print("Handle \(event) on main thread? \(Thread.isMainThread)")
        }, onError: { print("Error: \($0). On main thread? \(Thread.isMainThread)")
        }, onCompleted: { print("Completed. On main thread? \(Thread.isMainThread)") })

        subscription.disposed(by: aDisposableBag)
    }
    
    func original(){
        Observable.combineLatest(number1.rx.text.orEmpty,
                                 number2.rx.text.orEmpty,
                                 number3.rx.text.orEmpty) { textValue1,
                                                            textValue2,
                                                            textValue3 -> Int in
                return (Int(textValue1) ?? 0) + (Int(textValue2) ?? 0) + (Int(textValue3) ?? 0)
            }
            .map { $0.description }
            .bind(to: result.rx.text)
            .disposed(by: disposeBag)
    }
    
    deinit {
        print("deinit()")
    }
}
