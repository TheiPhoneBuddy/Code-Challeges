//
//  HTTPServiceResponse.swift
//  Demo
//
//  Created by Francis Chan on 5/24/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

import UIKit

class HTTPServiceResponse: NSObject {
    typealias callback = (HTTPServiceResponse?) -> Void
    
    var aryDataModel:Array<DataModel>? = []
    var dictPhotos:Dictionary<String,Any>? = [:]

    var errorMsg:String?
}
