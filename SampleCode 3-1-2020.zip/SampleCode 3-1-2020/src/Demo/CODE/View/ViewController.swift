//
//  ViewController.swift
//  Demo
//
//  Created by Francis Chan on 5/17/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

import UIKit
import ComponentKit
import CommonUtils

class ViewController: BaseViewController,
                      BasePresenterDelegate,
                      MBProgressHUDDelegate {

    /* Presenter Delegate Method(s) */
    func showProgress(){
        self.loadMBProgressHUD("Searching iTunes...")
    }
    
    func hideProgress(){
        weak var weakSelf = self
        DispatchQueue.main.async {
            weakSelf?.HUD.hide(true,afterDelay:0)
        }
    }
    
    func didMakeRequestSuccess() {
        weak var weakSelf = self
        DispatchQueue.main.async {
            weakSelf?.tableView.reloadData()
        }
    }
    
    func didMakeRequestFailed(_ errorMsg: String) {
        DispatchQueue.main.async {
            CommonUtils.displayAlert("", message: errorMsg,vc:self)
        }
    }

    /* Tableview Method(s) */
    override func numberOfSections(in tableView: UITableView) -> Int {
        return self.presenter.getSectionCount()
    }
    
    override func tableView(_ tableView: UITableView,
                            numberOfRowsInSection section: Int) -> Int {
        return self.presenter.getCount()
    }
    
    override func tableView(_ tableView: UITableView,
                            cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: cellReuseIdentifier,
                                                 for: indexPath) as! CustomCell
        cell.dataModel = self.presenter.getRec(indexPath.row)
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView,
                            didSelectRowAt indexPath: IndexPath){
        self.dataModel = self.presenter.getRec(indexPath.row)
        
        let vc = DetailViewController()
        vc.dataModel = self.dataModel
        vc.view.backgroundColor = UIColor.white
        self.navigationController?.pushViewController(vc, animated: true)
    }

    /* View Life Cycle Method(s) */
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.tableView.register(CustomCell.self,
                           forCellReuseIdentifier: cellReuseIdentifier)

        self.HUD.delegate = self
        self.presenter.delegate = self
        self.presenter.makeRequest()
    }
}
