//
//  BaseProtocol.swift
//  Coding Challenge
//
//  Created by Francis Chan on 5/25/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

protocol BaseProtocol: class {
    func didMakeRequestSuccess()
    func didMakeRequestFailed(_ errorMsg:String)

    func showProgress()
    func hideProgress()
}
