//
//  BasePresenter.swift
//  Coding Challenge
//
//  Created by Francis Chan on 5/25/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

import CommonUtils

protocol BasePresenterDelegate: BaseProtocol{}

class BasePresenter: NSObject {
    
    /* Private */
    fileprivate var aryData:Array<DataModel> = []
    fileprivate var dictPhotos:Dictionary<String,Any> = [:]

    /* Public */
    weak var delegate: BasePresenterDelegate?
    
    /* Public Method(s) */
    func makeRequest(){
        /* TESTING */
//        let urlString = CommonUtils.getPathToFile(fileName: "data")!
        let urlString:String = "https://rss.itunes.apple.com/api/v1/us/apple-music/coming-soon/all/100/explicit.json"
        
        self.getData(urlString)
    }
    
    func getSectionCount() -> Int{
        return 1
    }

    func getCount() -> Int{
        return self.aryData.count
    }

    func getRec(_ i:Int) -> DataModel{
        var dataModel:DataModel = aryData[i]
        dataModel.image = getImage(dataModel.id)
        
        return dataModel
    }

    /* Private Method(s) */
    fileprivate func getImage(_ id:String) -> UIImage? {
         if let tmp = self.dictPhotos[id] {
            let dict:Dictionary<String,Any>? = tmp as? Dictionary<String, Any>
            if let tmp = dict {
                let data:Data? = tmp["data"] as? Data
                if let tmp = data {
                   let image:UIImage? = UIImage(data: tmp)
                   return image
                }
             }
        }

        return nil
    }
    
    fileprivate func getData(_ urlString:String){
        self.delegate?.showProgress()
        
        let request:HTTPServiceRequest = HTTPServiceRequest()
        request.urlString = urlString
        
        weak var weakSelf = self
        let http:HTTPService = HTTPService()
        http.makeRequest(request,
          callback:{(response:HTTPServiceResponse?) -> Void in
            if response?.errorMsg == nil {
               /* aryDataModel */
               if let tmp = response?.aryDataModel {
                   weakSelf?.aryData = tmp
               }

               /* dictPhotos */
               if let tmp = response?.dictPhotos {
                  weakSelf?.dictPhotos = tmp
               }
                
               weakSelf?.delegate?.didMakeRequestSuccess()
            }else{
               weakSelf?.delegate?.didMakeRequestFailed(response!.errorMsg!)
            }
            weakSelf?.delegate?.hideProgress()
        })
    }
    
    deinit {
        print("BasePresenter:deinit")
    }
}
