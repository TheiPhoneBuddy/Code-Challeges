//
//  JPMCTests.swift
//  Coding Challenge
//
//  Created by Francis Chan on 6/14/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

import XCTest
@testable import JPMC

class JPMCTests: XCTestCase,BasePresenterDelegate {
    
    let timeout:Double = 10.0
    
    var expectation:XCTestExpectation?
    let expectationConstants:String = "testMakeRequest"
    
    var expectation2:XCTestExpectation?
    let expectation2Constants:String = "testMakeRequestDetails"
    
    var presenter:BasePresenter = BasePresenter()
    
    /* SetUp */
    override func setUp() {
        self.expectation = XCTestExpectation(description: self.expectationConstants)
        self.expectation2 = XCTestExpectation(description: self.expectation2Constants)
        
        self.presenter.delegate = self
    }
    
    override func tearDown() {}
    
    /* Presenter delegate method(s) */
    func didMakeRequestSuccess() {
        if self.expectation?.expectationDescription == self.expectationConstants{
            self.expectation?.fulfill()
        }
        
        if self.expectation2?.expectationDescription == self.expectation2Constants{
            self.expectation2?.fulfill()
        }
    }
    
    func didMakeRequestFailed(_ errorMsg: String) {
        if self.expectation?.expectationDescription == self.expectationConstants{
            self.expectation?.fulfill()
        }
        
        if self.expectation2?.expectationDescription == self.expectation2Constants{
            self.expectation2?.fulfill()
        }
    }
    
    func showProgress() {
    }
    
    func hideProgress() {
    }
    
    /* Test "make request" & "make request details", "Happy Path"  */
    func testMakeRequest() {
        self.presenter.makeRequest()
        wait(for: [self.expectation!], timeout: self.timeout)
    }
    
    func testMakeRequestDetails() {
        let dbn:String = "123"
        self.presenter.makeRequest(dbn)
        wait(for: [self.expectation2!], timeout: self.timeout)
    }
}

