//
//  BasePresenter.swift
//  Coding Challenge
//
//  Created by Francis Chan on 6/14/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

import CommonUtils

protocol BasePresenterDelegate: BaseProtocol{}

class BasePresenter: NSObject {
    
    /* Private */
    fileprivate let DEBUG:Bool = true
    fileprivate var aryData:Array<DataModel> = []

    /* Public */
    var limit:Int = 100
    var offset:Int = 0
    weak var delegate: BasePresenterDelegate?
    
    /* Public Method(s) */
    func makeRequest(){
        var urlString:String = "https://data.cityofnewyork.us/resource/97mf-9njv.json"
        urlString = urlString + "?$$app_token="
        urlString = urlString + Common.getAPIKey()
        urlString = urlString + "&$limit="
        urlString = urlString + String(self.limit)
        urlString = urlString + "&$offset="
        urlString = urlString + String(self.offset)
        
        self.getData(urlString)
    }

    func makeRequest(_ dbn:String){
        var urlString:String = "https://data.cityofnewyork.us/resource/734v-jeq5.json"
        urlString = urlString + "?$$app_token="
        urlString = urlString + Common.getAPIKey()
        urlString = urlString + "&dbn="
        urlString = urlString + dbn
        
        self.getData(urlString)
    }
    
    func getSectionCount() -> Int{
        return 1
    }

    func getCount() -> Int{
        return self.aryData.count
    }

    func getRec(_ i:Int) -> DataModel{
        return aryData[i]
    }
    
    /* Private Method(s) */
    fileprivate func getData(_ urlString:String){
        self.delegate?.showProgress()
        
        weak var weakSelf = self
        let http:HTTPService = HTTPService()
        http.makeRequest(urlString) {(aryDataModel,errorMsg) in
            if errorMsg == nil{
                if let aryData = aryDataModel {
                    weakSelf?.aryData = aryData
                    weakSelf?.delegate?.didMakeRequestSuccess()
                }else{
                    weakSelf?.delegate?.didMakeRequestFailed("Error in 'BasePresenter:getData'.")
                }
             }else{
                weakSelf?.delegate?.didMakeRequestFailed(errorMsg ?? "")
             }
             weakSelf?.delegate?.hideProgress()
        }
    }
    
    deinit {
        if DEBUG == true {
            //print("BasePresenter:deinit")
        }
    }
}
