//
//  BaseProtocol.swift
//  Coding Challenge
//
//  Created by Francis Chan on 6/14/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

protocol BaseProtocol: class {
    func didMakeRequestSuccess()
    func didMakeRequestFailed(_ errorMsg:String)

    func showProgress()
    func hideProgress()
}
