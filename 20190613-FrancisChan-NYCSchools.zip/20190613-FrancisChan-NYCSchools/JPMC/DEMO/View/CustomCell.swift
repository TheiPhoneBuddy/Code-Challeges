//
//  CustomCell.swift
//  Coding Challenge
//
//  Created by Francis Chan on 6/14/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

import UIKit

class CustomCell: UITableViewCell {

    @IBOutlet weak var school_name: UILabel!
    @IBOutlet weak var overview_paragraph: UILabel!

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
}
