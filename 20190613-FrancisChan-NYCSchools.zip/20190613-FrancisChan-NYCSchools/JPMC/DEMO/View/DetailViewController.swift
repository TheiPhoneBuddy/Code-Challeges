//
//  DetailViewController.swift
//  Coding Challenge
//
//  Created by Francis Chan on 2/2/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

import UIKit
import CommonUtils
import ComponentKit

class DetailViewController: UIViewController,
                            BasePresenterDelegate,
                            MBProgressHUDDelegate {
    
    /* IBOutlet(s) */
    @IBOutlet weak var school_name: UILabel!
    @IBOutlet weak var num_of_sat_test_takers: UILabel!
    @IBOutlet weak var sat_critical_reading_avg_score: UILabel!
    @IBOutlet weak var sat_math_avg_score: UILabel!
    @IBOutlet weak var sat_writing_avg_score: UILabel!
    @IBOutlet weak var overview_paragraph: UILabel!

    /* Public */
    var dataModel:DataModel?

    /* Private */
    fileprivate var presenter:BasePresenter = BasePresenter()    
    fileprivate var HUD:MBProgressHUD = MBProgressHUD()

    /* Presenter Delegate Method(s) */
    func showProgress(){
        self.loadMBProgressHUD("School Detail Data")
    }
    
    func hideProgress(){
        weak var weakSelf = self
        DispatchQueue.main.async {
            weakSelf?.HUD.hide(true,afterDelay:0)
        }
    }
    
    func didMakeRequestSuccess() {
        weak var weakSelf = self
        DispatchQueue.main.async {
            weakSelf?.school_name.text = self.presenter.getRec(0).school_name
            weakSelf?.num_of_sat_test_takers.text = "No of test takers: " + self.presenter.getRec(0).num_of_sat_test_takers
            weakSelf?.sat_critical_reading_avg_score.text = "SAT Reading ave. score: " +  self.presenter.getRec(0).sat_critical_reading_avg_score
            weakSelf?.sat_math_avg_score.text = "SAT Math ave. score: " + self.presenter.getRec(0).sat_math_avg_score
            weakSelf?.sat_writing_avg_score.text = "SAT Writing ave. score: " + self.presenter.getRec(0).sat_writing_avg_score
            weakSelf?.overview_paragraph.text = self.dataModel?.overview_paragraph
        }
    }
    
    func didMakeRequestFailed(_ errorMsg: String) {
        DispatchQueue.main.async {
            CommonUtils.displayAlert("", message: errorMsg,vc:self)
        }
    }
    
    /* View Life Cycle Method(s) */
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.HUD.delegate = self
        self.presenter.delegate = self
        self.presenter.makeRequest(self.dataModel?.dbn ?? "")
     }
    
    /* Private Method(s) */
    fileprivate func loadMBProgressHUD(_ msg:String){
        self.view.addSubview(HUD)
        
        HUD.dimBackground = true
        HUD.labelText = "Searching for "
        
        HUD.detailsLabelText = msg
        HUD.show(true)
    }
    
    deinit {
        //print("DetailViewController:deinit")
    }
}
