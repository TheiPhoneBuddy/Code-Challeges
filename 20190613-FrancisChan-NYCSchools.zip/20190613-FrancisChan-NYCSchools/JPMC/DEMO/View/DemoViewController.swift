//
//  DemoViewController.swift
//  Coding Challenge
//
//  Created by Francis Chan on 6/14/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

import UIKit
import ComponentKit
import CommonUtils

class DemoViewController: BaseViewController,
                          BasePresenterDelegate,
                          MBProgressHUDDelegate {
    
    /* Presenter Delegate Method(s) */
    func showProgress(){
        self.loadMBProgressHUD("School Data")
    }
    
    func hideProgress(){
        weak var weakSelf = self
        DispatchQueue.main.async {
            weakSelf?.HUD.hide(true,afterDelay:0)
        }
    }
    
    func didMakeRequestSuccess() {
        weak var weakSelf = self
        DispatchQueue.main.async {
            weakSelf?.tableView.reloadData()
        }
    }
    
    func didMakeRequestFailed(_ errorMsg: String) {
        DispatchQueue.main.async {
            CommonUtils.displayAlert("", message: errorMsg,vc:self)
        }
    }

    /* Tableview Method(s) */
    override func numberOfSections(in tableView: UITableView) -> Int {
        return self.presenter.getSectionCount()
    }
    
    override func tableView(_ tableView: UITableView,
                            numberOfRowsInSection section: Int) -> Int {
        return self.presenter.getCount()
    }
    
    override func tableView(_ tableView: UITableView,
                            cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cell = tableView.dequeueReusableCell(withIdentifier: "CustomCell",
                                                 for: indexPath) as! CustomCell

        let dataModel:DataModel = self.presenter.getRec(indexPath.row)
        cell.school_name.text = dataModel.school_name
        cell.overview_paragraph.text = dataModel.overview_paragraph
 
        return cell
    }
    
    override func tableView(_ tableView: UITableView,
                            didSelectRowAt indexPath: IndexPath){
        
        self.dataModel = self.presenter.getRec(indexPath.row)
        performSegue(withIdentifier: "showDetail", sender: self)
    }
    
    /* View Life Cycle Method(s) */
    override func viewDidLoad() {
        super.viewDidLoad()
        
        self.HUD.delegate = self
        self.presenter.delegate = self
        self.presenter.makeRequest()
    }
}
