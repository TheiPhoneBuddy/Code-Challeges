//
//  Common.swift
//  Coding Challenge
//
//  Created by Francis Chan on 6/14/19.
//  Copyright © 2017 TheiPhoneBuddy. All rights reserved.
//

import UIKit

class Common: NSObject {
    fileprivate static let API_KEY:String = "kpvCcwQJwlPPEZD8poxSF6yb6"

    /* Public Method(s) */
    static func getAPIKey() -> String {
        return API_KEY
    }
}
