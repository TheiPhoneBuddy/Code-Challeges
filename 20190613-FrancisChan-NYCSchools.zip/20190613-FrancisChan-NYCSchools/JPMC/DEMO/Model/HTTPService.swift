//
//  HTTPService.swift
//  Coding Challenge
//
//  Created by Francis Chan on 6/14/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

import UIKit
import HTTPManager
import CoreLocation

class HTTPService: NSObject {
    
    typealias HTTPServiceCallback = (Array<DataModel>?,String?) -> Void

    fileprivate var callback:HTTPServiceCallback?
    
    /* Public Method(s) */
    func makeRequest(_ urlString:String?,
                      completion:@escaping(_ data:Array<DataModel>?,
                                       _ errorMsg:String?) -> Void) {
        if urlString == nil {
            completion(nil,"'urlString' param cannot be nil!")
            return
        }
        
        let request: [String: String] = ["urlString": urlString!,
                                         "requestID":""]
        
        /*
         "HTTPManager.framework" is a free dynamic network library I developed in swift
         and can be downloaded from my GitHub acct. at:
         
         https://github.com/TheiPhoneBuddy/HTTPManager
         
         "FastFoodApp","TheDailyNewsApp","TheiPhoneBuddy" and other apps use this library
          that is in production e.g. App Store.
         */
        HTTPManager.getData(request,
                            callback:{(resp:Dictionary<String,Any>?,
                            errorMsg:String?) -> Void in
            
            if((errorMsg) != nil){
                completion(nil,errorMsg)
            }else{
                
                let aryResults:Array<Any>? = resp?["responseDict"] as? Array<Any>
                if aryResults == nil || aryResults?.count == 0 {
                    completion(nil,"No Data Returned.")
                    return
                }
                
                var aryDataModel:Array<DataModel>? = []
                for data in aryResults! {
                    
                    var dict:Dictionary<String,Any>? = data as? Dictionary<String,Any>
                    var dataModel:DataModel? = DataModel()
                    
                     /* dbn */
                    let dbn:String? = dict!["dbn"] as? String
                    if let tmp = dbn {
                        dataModel?.dbn = tmp
                    }

                    /* school_name */
                    let school_name:String? = dict!["school_name"] as? String
                    if let tmp = school_name {
                        dataModel?.school_name = tmp
                    }
                    
                    /* overview_paragraph */
                    let overview_paragraph:String? = dict!["overview_paragraph"] as? String
                    if let tmp = overview_paragraph {
                        dataModel?.overview_paragraph = tmp
                    }
 
                    /* num_of_sat_test_takers */
                    let num_of_sat_test_takers:String? = dict!["num_of_sat_test_takers"] as? String
                    if let tmp = num_of_sat_test_takers {
                        dataModel?.num_of_sat_test_takers = tmp
                    }

                    /* sat_critical_reading_avg_score */
                    let sat_critical_reading_avg_score:String? = dict!["sat_critical_reading_avg_score"] as? String
                    if let tmp = sat_critical_reading_avg_score {
                        dataModel?.sat_critical_reading_avg_score = tmp
                    }

                    /* sat_math_avg_score */
                    let sat_math_avg_score:String? = dict!["sat_math_avg_score"] as? String
                    if let tmp = sat_math_avg_score {
                        dataModel?.sat_math_avg_score = tmp
                    }

                    /* sat_writing_avg_score */
                    let sat_writing_avg_score:String? = dict!["sat_writing_avg_score"] as? String
                    if let tmp = sat_writing_avg_score {
                        dataModel?.sat_writing_avg_score = tmp
                    }

                    /* aryDataModel */
                    if let tmp = dataModel {
                        aryDataModel?.append(tmp)
                    }
                    dataModel = nil
                }
                
                completion(aryDataModel,nil)
                
            }//if
                                
        })//HTTPManager
    }
    
    /* Private Method(s) */
    deinit {
        //print("HTTPService:deinit")
    }
}
