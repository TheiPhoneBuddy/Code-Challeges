//
//  HTTPManager.h
//  WeatherApp
//
//  Created by Francis Chan on 2/6/18.
//  Copyright © 2018 TheiPhoneBuddy. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "Request.h"

@interface HTTPManager : NSObject

#pragma Used for async callback

typedef void(^HTTPManagerCallback)(id resp,NSString *errorMsg);

#pragma Public Method(s)

- (void)getData:(HTTPManagerCallback)callback
           request:(Request *)request;
@end
