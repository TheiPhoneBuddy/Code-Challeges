//
//  Utils.h
//  WeatherApp
//
//  Created by Francis Chan on 2/6/18.
//  Copyright © 2018 TheiPhoneBuddy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Utils : NSObject

#pragma Public Method(s)

+ (NSMutableArray *)parseData:(NSDictionary *)json;

@end
