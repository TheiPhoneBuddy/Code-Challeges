//
//  Utils.m
//  WeatherApp
//
//  Created by Francis Chan on 2/6/18.
//  Copyright © 2018 TheiPhoneBuddy. All rights reserved.
//

#import "Utils.h"
#import "Weather.h"

@implementation Utils

#pragma Private Method(s)

+ (NSDate *)utcToLocalTime:(NSDate*)date {
    NSTimeZone *currentTimeZone = [NSTimeZone defaultTimeZone];
    NSInteger secondsOffset = [currentTimeZone secondsFromGMTForDate:date];
    return [NSDate dateWithTimeInterval:secondsOffset sinceDate:date];
}

#pragma Public Method(s)

+ (NSMutableArray *)parseData:(NSDictionary *)json{

    NSMutableArray *aryData = [[NSMutableArray alloc] init];

    for (NSDictionary *dict in json[@"list"]) {
        @autoreleasepool {
            
            Weather *obj = [[Weather alloc] init];
            
            /* day */
            double dt = [dict[@"dt"] doubleValue];
            NSDate *day = [self utcToLocalTime:[NSDate dateWithTimeIntervalSince1970:dt]];
            
            NSDateFormatter *dateFormatter = [[NSDateFormatter alloc] init];
            [dateFormatter setDateFormat:@"EEEE"];
            
            if(day){
                obj.day = [dateFormatter stringFromDate:day];
            }
            
            /* celsius */
            NSDictionary *temp = dict[@"temp"];
            
            obj.celsiusMorn = [temp[@"morn"] floatValue];
            obj.celsiusDay = [temp[@"day"] floatValue];
            obj.celsiusNight = [temp[@"night"] floatValue];
            obj.celsiusEve = [temp[@"eve"] floatValue];
            
            /* fahrenheit */
            obj.fahrenheitMorn = (obj.celsiusMorn * 1.8) + 32;
            obj.fahrenheitDay = (obj.celsiusDay * 1.8) + 32;
            obj.fahrenheitEve = (obj.celsiusEve * 1.8) + 32;
            obj.fahrenheitNight = (obj.celsiusNight * 1.8) + 32;
            
            /* img */
            NSArray *weather = dict[@"weather"];
            
            for (NSDictionary *dict in weather){
                obj.desc = dict[@"description"];
                obj.main = dict[@"main"];
                obj.idKey = [dict[@"id"] intValue];
                
                obj.img = dict[@"icon"];
                obj.img = [obj.img stringByAppendingString:@".png"];
            }
            
            [aryData addObject:obj];
            obj = nil;
        }
    }
    
    return aryData;
}
@end
