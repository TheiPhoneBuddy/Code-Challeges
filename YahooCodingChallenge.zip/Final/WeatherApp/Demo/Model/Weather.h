//
//  Weather.h
//  WeatherApp
//
//  Created by Francis Chan on 2/6/18.
//  Copyright © 2018 TheiPhoneBuddy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Weather : NSObject

@property(nonatomic,nullable) NSString *day;

@property(nonatomic,nullable) NSString *img;
@property(nonatomic,nullable) NSString *desc;
@property(nonatomic,nullable) NSString *main;
@property(nonatomic) NSInteger idKey;

/* celsius */
@property(nonatomic) float celsiusDay;
@property(nonatomic) float celsiusEve;
@property(nonatomic) float celsiusMorn;
@property(nonatomic) float celsiusNight;

/* fahrenheit */
@property(nonatomic) float fahrenheitDay;
@property(nonatomic) float fahrenheitEve;
@property(nonatomic) float fahrenheitMorn;
@property(nonatomic) float fahrenheitNight;

@end
