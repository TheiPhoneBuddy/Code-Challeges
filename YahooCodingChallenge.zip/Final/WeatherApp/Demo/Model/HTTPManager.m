//
//  HTTPManager.m
//  WeatherApp
//
//  Created by Francis Chan on 2/6/18.
//  Copyright © 2018 TheiPhoneBuddy. All rights reserved.
//

#import "HTTPManager.h"

@implementation HTTPManager

#pragma Private Method(s)

- (NSString *)getUrl{
    NSString *appid=@"adb4503a31093fed77c0a5f39d4c512b";
    NSString *urlString =  @"http://api.openweathermap.org/data/2.5/forecast/daily?q=Sunnyvale&mode=json&units=metric&cnt=7&appid=";
    urlString = [urlString stringByAppendingString:appid];
    
    return urlString;
}

#pragma Public Method(s)

- (void)getData:(HTTPManagerCallback)callback
        request:(Request *)request{

    /* If none is specified, use default url */
    if(!request.urlString){
        request.urlString = [self getUrl];
    }
    
    NSURL *url = [NSURL URLWithString:request.urlString];
    NSURLSessionDataTask *downloadTask = [[NSURLSession sharedSession]
              dataTaskWithURL:url completionHandler:^(NSData *data,
                                                      NSURLResponse *response,
                                                      NSError *error) {
                  
      dispatch_after(dispatch_time(DISPATCH_TIME_NOW,
                                   (int64_t)(.05f * NSEC_PER_SEC)),
                 dispatch_get_main_queue(), ^{
                     
                     if(error){
                         callback(nil,error.localizedDescription);
                     }else{
                         
                         if (request.dataFlag){
                             callback(data,nil);
                         }else{
                             NSError* error;
                             NSDictionary *json = [NSJSONSerialization
                                                   JSONObjectWithData:data
                                                              options:kNilOptions
                                                                error:&error];
                             
                             callback(json,nil);
                         }
                     }
                 });
                  
              }];
    [downloadTask resume];
}
@end
