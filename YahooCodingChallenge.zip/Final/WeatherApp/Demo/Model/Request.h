//
//  Request.h
//  WeatherApp
//
//  Created by Francis Chan on 2/6/18.
//  Copyright © 2018 TheiPhoneBuddy. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface Request : NSObject

@property(nonatomic,nullable) NSString *urlString;
@property(nonatomic) BOOL dataFlag;

@end
