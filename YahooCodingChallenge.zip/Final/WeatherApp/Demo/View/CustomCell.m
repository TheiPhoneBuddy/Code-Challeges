//
//  CustomCell.m
//  WeatherApp
//
//  Created by Francis Chan on 2/5/18.
//  Copyright © 2018 TheiPhoneBuddy. All rights reserved.
//

#import "CustomCell.h"

@implementation CustomCell

- (void)awakeFromNib {
    [super awakeFromNib];
    // Initialization code
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated {
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
