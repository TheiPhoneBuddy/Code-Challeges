//
//  CustomCell.h
//  WeatherApp
//
//  Created by Francis Chan on 2/5/18.
//  Copyright © 2018 TheiPhoneBuddy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CustomCell : UITableViewCell

@property(nonatomic,weak,nullable) IBOutlet UILabel *day;
@property(nonatomic,weak,nullable) IBOutlet UILabel *temp;
@property(nonatomic,weak,nullable) IBOutlet UIImageView *img;

@end
