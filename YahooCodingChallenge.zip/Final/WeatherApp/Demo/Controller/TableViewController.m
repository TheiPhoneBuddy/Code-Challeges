//
//  TableViewController.m
//  WeatherApp
//
//  Created by Francis Chan on 2/5/18.
//  Copyright © 2018 TheiPhoneBuddy. All rights reserved.
//

#import "TableViewController.h"
#import "CustomCell.h"
#import "Weather.h"
#import "HTTPManager.h"
#import "Utils.h"

@interface TableViewController (){
    @private
       /* Hold array of dict. */
       NSMutableArray *aryData;
    
       /* Used to hold downloaded images. */
       NSMutableDictionary *images;
    
       BOOL fahrenheitFlag;
}
@end

@implementation TableViewController

#pragma Action Method(s)

- (IBAction)fahrenheit:(id)sender {
    if (fahrenheitFlag){
        [self.tableView reloadData];
        fahrenheitFlag =  NO;

    }else{
        [self.tableView reloadData];
        fahrenheitFlag =  YES;
    }
}

#pragma HTTTP Method(s)

- (void)getData{
    Request *request = [[Request alloc] init];
    
    __typeof(self) __weak weakSelf = self;
    HTTPManager *obj = [[HTTPManager alloc] init];
    [obj getData:^(NSDictionary *resp, NSString *errorMsg) {
        
        if(errorMsg){
            NSLog(@"%@",errorMsg);
        }else{
            aryData = [Utils parseData:resp];
            [weakSelf.tableView reloadData];
        }
    } request:request];
}

- (void)getImages:(NSIndexPath *)indexPath cell:(CustomCell *)cell{
    Weather *obj = [aryData objectAtIndex:indexPath.row];

    NSString *img = obj.img;
    NSString *urlString=@"http://openweathermap.org/img/w/";
    urlString = [urlString stringByAppendingString:img];

    /* Check if image is already dowloaded */
    if(images[img]){
        cell.img.image=images[img];
        return;
    }
    
    Request *request = [[Request alloc] init];
    request.urlString = urlString;
    request.dataFlag = YES;

    HTTPManager *oHTTPManager = [[HTTPManager alloc] init];
    [oHTTPManager getData:^(NSData *resp, NSString *errorMsg) {
        
        if(errorMsg){
          cell.img.image=[UIImage imageNamed:@"Placeholder.png"];
          return;
        }else{
           UIImage *image = [UIImage imageWithData: resp];
           cell.img.image=image;

           /* Add downloaded image to dictionary for next time. */
           [images setValue:image forKey:img];

           NSLog(@"%@",urlString);
        }
    } request:request];
}

#pragma Tableview Method(s)

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [aryData count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    
    NSString *identifierFromStoryboard = @"CustomCell";
    CustomCell *cell = [tableView dequeueReusableCellWithIdentifier:identifierFromStoryboard
                                                       forIndexPath:indexPath];
    
    static NSString *reuseIdentifier = @"MyCell";
    if (!cell) {
        cell = [[CustomCell alloc] initWithStyle:UITableViewCellStyleDefault
                                 reuseIdentifier:reuseIdentifier];
    }

    Weather *obj=[aryData objectAtIndex:indexPath.row];
    cell.day.text = obj.day;
    
    if(fahrenheitFlag){
        cell.temp.text = [NSString stringWithFormat:@"%.0f", obj.fahrenheitDay];
    }else{
        NSString *tmp = [NSString stringWithFormat:@"%.0f", obj.celsiusDay];
        tmp = [tmp stringByAppendingString:@" c"];
        cell.temp.text = tmp;
    }

    [self getImages:indexPath cell:cell];

    return cell;
}

#pragma View Life Cycle Method(s)

- (void)viewDidLoad {
    [super viewDidLoad];
    
    /* Display Fahrenheit 1st!  */
    fahrenheitFlag = YES;
    
    /* Hold array of Weather objects */
    aryData = [[NSMutableArray alloc] init];

    /* Used to cache images. */
    images = [[NSMutableDictionary alloc] init];
    
    /* Get json payload. */
    [self getData];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
    /* Remove all images when running low on memory. */
    [images removeAllObjects];
}
@end
