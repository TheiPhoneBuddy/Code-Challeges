//
//  DetailViewController.swift
//  Demo
//
//  Created by Francis Chan on 5/25/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    /* Detail data */
    var dataModel:DataModel?

    func addImage(){
        let imageViewData =  UIImageView(image: dataModel?.image)
        imageViewData.contentMode = .scaleAspectFill
        imageViewData.clipsToBounds = true
        imageViewData.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(imageViewData)
        
        let leading = NSLayoutConstraint(item: imageViewData,
                                         attribute: .leading,
                                         relatedBy: .equal,
                                         toItem: self.view,
                                         attribute: .leading,
                                         multiplier: 1.0,
                                         constant: 20.0)
        
        let trailing = NSLayoutConstraint(item: imageViewData,
                                          attribute: .trailing,
                                          relatedBy: .equal,
                                          toItem: self.view,
                                          attribute: .trailing,
                                          multiplier: 1.0,
                                          constant: -20.0)
        
        let top = NSLayoutConstraint(item: imageViewData,
                                     attribute: .top,
                                     relatedBy: .equal,
                                     toItem: self.view,
                                     attribute: .top,
                                     multiplier: 1.0,
                                     constant: 100.0)
        
        let height = NSLayoutConstraint(item: imageViewData,
                                        attribute: .height,
                                        relatedBy: .equal,
                                        toItem: nil,
                                        attribute: .notAnAttribute,
                                        multiplier: 1.0,
                                        constant: 220.0)
        
        self.view.addConstraint(leading)
        self.view.addConstraint(trailing)
        self.view.addConstraint(top)
        self.view.addConstraint(height)
    }
    
    func addArtistName(){
        let artistName = UILabel()
        artistName.textColor = .black
        artistName.font = UIFont.boldSystemFont(ofSize: 26)
        artistName.textAlignment = .left
        artistName.numberOfLines = 2
        artistName.text = dataModel?.artistName
        artistName.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(artistName)
        
        let top = NSLayoutConstraint(item: artistName,
                                     attribute: .top,
                                     relatedBy: .equal,
                                     toItem: self.view,
                                     attribute: .top,
                                     multiplier: 1.0,
                                     constant: 330.0)
        
        let leading = NSLayoutConstraint(item: artistName,
                                         attribute: .leading,
                                         relatedBy: .equal,
                                         toItem: self.view,
                                         attribute: .leading,
                                         multiplier: 1.0,
                                         constant: 20.0)
        
        let width = NSLayoutConstraint(item: artistName,
                                       attribute: .width,
                                       relatedBy: .equal,
                                       toItem: nil,
                                       attribute: .notAnAttribute,
                                       multiplier: 1.0,
                                       constant: 400.0)
        
        self.view.addConstraint(top)
        self.view.addConstraint(leading)
        self.view.addConstraint(width)
    }
    
    func addName(){
        let name = UILabel()
        name.textColor = .black
        name.font = UIFont.boldSystemFont(ofSize:16)
        name.textAlignment = .left
        name.numberOfLines = 2
        name.text = "Name: " + dataModel!.name
        name.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(name)
        
        let top = NSLayoutConstraint(item: name,
                                     attribute: .top,
                                     relatedBy: .equal,
                                     toItem: self.view,
                                     attribute: .top,
                                     multiplier: 1.0,
                                     constant: 360.0)
        
        let leading = NSLayoutConstraint(item: name,
                                         attribute: .leading,
                                         relatedBy: .equal,
                                         toItem: self.view,
                                         attribute: .leading,
                                         multiplier: 1.0,
                                         constant: 20.0)
        
        let width = NSLayoutConstraint(item: name,
                                       attribute: .width,
                                       relatedBy: .equal,
                                       toItem: nil,
                                       attribute: .notAnAttribute,
                                       multiplier: 1.0,
                                       constant: 400.0)
        
        self.view.addConstraint(top)
        self.view.addConstraint(leading)
        self.view.addConstraint(width)
    }
    
    func addGenre(){
        let name = UILabel()
        name.textColor = .black
        name.font = UIFont.boldSystemFont(ofSize:16)
        name.textAlignment = .left
        name.numberOfLines = 2
        name.text = "Genre: " + dataModel!.genre
        name.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(name)
        
        let top = NSLayoutConstraint(item: name,
                                     attribute: .top,
                                     relatedBy: .equal,
                                     toItem: self.view,
                                     attribute: .top,
                                     multiplier: 1.0,
                                     constant: 380.0)
        
        let leading = NSLayoutConstraint(item: name,
                                         attribute: .leading,
                                         relatedBy: .equal,
                                         toItem: self.view,
                                         attribute: .leading,
                                         multiplier: 1.0,
                                         constant: 20.0)
        
        let width = NSLayoutConstraint(item: name,
                                       attribute: .width,
                                       relatedBy: .equal,
                                       toItem: nil,
                                       attribute: .notAnAttribute,
                                       multiplier: 1.0,
                                       constant: 400.0)
        
        self.view.addConstraint(top)
        self.view.addConstraint(leading)
        self.view.addConstraint(width)
    }
    
    func addDate(){
        let name = UILabel()
        name.textColor = .black
        name.font = UIFont.boldSystemFont(ofSize:16)
        name.textAlignment = .left
        name.numberOfLines = 2
        name.text = "Date: " + dataModel!.releaseDate
        name.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(name)
        
        let top = NSLayoutConstraint(item: name,
                                     attribute: .top,
                                     relatedBy: .equal,
                                     toItem: self.view,
                                     attribute: .top,
                                     multiplier: 1.0,
                                     constant: 400.0)
        
        let leading = NSLayoutConstraint(item: name,
                                         attribute: .leading,
                                         relatedBy: .equal,
                                         toItem: self.view,
                                         attribute: .leading,
                                         multiplier: 1.0,
                                         constant: 20.0)
        
        let width = NSLayoutConstraint(item: name,
                                       attribute: .width,
                                       relatedBy: .equal,
                                       toItem: nil,
                                       attribute: .notAnAttribute,
                                       multiplier: 1.0,
                                       constant: 400.0)
        
        self.view.addConstraint(top)
        self.view.addConstraint(leading)
        self.view.addConstraint(width)
    }
    
    func addCopyRight(){
        let name = UILabel()
        name.textColor = .black
        name.font = UIFont.boldSystemFont(ofSize:16)
        name.textAlignment = .left
        name.numberOfLines = 2
        name.text = "Copy Right: " + dataModel!.copyright
        name.translatesAutoresizingMaskIntoConstraints = false
        self.view.addSubview(name)
        
        let top = NSLayoutConstraint(item: name,
                                     attribute: .top,
                                     relatedBy: .equal,
                                     toItem: self.view,
                                     attribute: .top,
                                     multiplier: 1.0,
                                     constant: 400.0)
        
        let leading = NSLayoutConstraint(item: name,
                                         attribute: .leading,
                                         relatedBy: .equal,
                                         toItem: self.view,
                                         attribute: .leading,
                                         multiplier: 1.0,
                                         constant: 20.0)
        
        let width = NSLayoutConstraint(item: name,
                                       attribute: .width,
                                       relatedBy: .equal,
                                       toItem: nil,
                                       attribute: .notAnAttribute,
                                       multiplier: 1.0,
                                       constant: 400.0)
        
        self.view.addConstraint(top)
        self.view.addConstraint(leading)
        self.view.addConstraint(width)
    }
    
    func addButton(){
        let btn:UIButton = UIButton(type: .custom)
        btn.backgroundColor = UIColor.blue
        btn.setTitle("Go To iTunes", for: .normal)
        btn.setTitleColor(.white, for: .normal)
        btn.translatesAutoresizingMaskIntoConstraints = false
        
        let btnAction = #selector(DetailViewController.btnAction(_:))
        btn.addTarget(self, action: btnAction, for: .touchUpInside)
        
        self.view.addSubview(btn)
        
        let bottom = NSLayoutConstraint(item: btn,
                                     attribute: .bottom,
                                     relatedBy: .equal,
                                     toItem: self.view,
                                     attribute: .bottom,
                                     multiplier: 1.0,
                                     constant: 20.0)

        let leading = NSLayoutConstraint(item: btn,
                                         attribute: .leading,
                                         relatedBy: .equal,
                                         toItem: self.view,
                                         attribute: .leading,
                                         multiplier: 1.0,
                                         constant: 20.0)
        
        let trailing = NSLayoutConstraint(item: btn,
                                          attribute: .trailing,
                                          relatedBy: .equal,
                                          toItem: self.view,
                                          attribute: .trailing,
                                          multiplier: 1.0,
                                          constant: -20.0)
        
        let height = NSLayoutConstraint(item: btn,
                                        attribute: .height,
                                        relatedBy: .equal,
                                        toItem: nil,
                                        attribute: .notAnAttribute,
                                        multiplier: 1.0,
                                        constant: 80.0)
        
        self.view.addConstraint(leading)
        self.view.addConstraint(trailing)
        self.view.addConstraint(bottom)
        self.view.addConstraint(height)
    }
    
    @objc func btnAction(_ sender: UIButton) {        
        if let url = URL(string: self.dataModel!.url) {
            UIApplication.shared.open(url)
        }
     }

    /* View Life Cycle Method(s) */
    override func viewDidLoad() {
        super.viewDidLoad()
        addImage()
        addArtistName()
        addName()
        addGenre()
        addCopyRight()
        addButton()
    }
}
