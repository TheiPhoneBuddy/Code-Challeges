//
//  CustomCell.swift
//  Coding Challenge
//
//  Created by Francis Chan on 5/25/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

import UIKit

class CustomCell: UITableViewCell {

    public var dataModel : DataModel? {
        didSet {
            artistName.text = dataModel?.artistName
            name.text = dataModel?.name
            imageViewData.image = dataModel?.image
        }
    }

    /* artistName */
    private let artistName : UILabel = {
        let lbl = UILabel()
        lbl.textColor = .black
        lbl.font = UIFont.boldSystemFont(ofSize: 16)
        lbl.textAlignment = .left
        return lbl
    }()

    /* name */
    private let name : UILabel = {
        let lbl = UILabel()
        lbl.textColor = .black
        lbl.font = UIFont.systemFont(ofSize: 12)
        lbl.textAlignment = .left
        lbl.numberOfLines = 2
        return lbl
    }()

    /* imageViewData */
    private let imageViewData : UIImageView = {
        let image:UIImage = UIImage(named: "placeHolder")!
        let imgView =  UIImageView(image: image)
        imgView.contentMode = .scaleAspectFill
        imgView.clipsToBounds = true
        return imgView
    }()

    override func awakeFromNib() {
        super.awakeFromNib()
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
    }
    
    override init(style: UITableViewCell.CellStyle,
                  reuseIdentifier: String?) {
        super.init(style: style, reuseIdentifier: reuseIdentifier)
        
        addSubview(imageViewData)
        addSubview(artistName)
        addSubview(name)
        
        imageViewData.anchor(top: topAnchor,
                            left: leftAnchor,
                            bottom: bottomAnchor,
                            right: nil,
                            paddingTop: 5,
                            paddingLeft: 5,
                            paddingBottom: 5,
                            paddingRight: 0,
                            width: 90,
                            height: 90,
                            enableInsets: false)
        
        artistName.anchor(top: topAnchor,
                          left: imageViewData.rightAnchor,
                        bottom: nil,
                        right: nil,
                        paddingTop: 20,
                        paddingLeft: 10,
                        paddingBottom: 0,
                        paddingRight: 0,
                        width: frame.size.width / 2,
                        height: 0,
                        enableInsets: false)
        
        name.anchor(top: artistName.bottomAnchor,
                    left: imageViewData.rightAnchor,
                   bottom: nil,
                   right: nil,
                   paddingTop: 0,
                   paddingLeft: 10,
                   paddingBottom: 0,
                   paddingRight: 0,
                   width: frame.size.width / 2,
                   height: 0,
                   enableInsets: false)
     }
    
    required init?(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
}
