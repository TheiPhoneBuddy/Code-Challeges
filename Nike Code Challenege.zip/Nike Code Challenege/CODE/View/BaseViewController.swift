//
//  BaseViewController.swift
//  Coding Challenge
//
//  Created by Francis Chan on 5/25/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

import UIKit
import CommonUtils
import ComponentKit

class BaseViewController: UITableViewController {

    let cellReuseIdentifier:String = "CustomCell"
    
    /* Presenter */
    var presenter:BasePresenter = BasePresenter()

    /* MBProgressHUD */
    var HUD:MBProgressHUD = MBProgressHUD()

    /* Detail data */
    var dataModel:DataModel?
    
    /* HUD */
    func loadMBProgressHUD(_ msg:String){
        self.view.addSubview(HUD)
        
        HUD.dimBackground = true
        HUD.labelText = "Searching for "
        
        HUD.detailsLabelText = msg
        HUD.show(true)
    }
    
    /* Storyboard Method(s)*/
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail" {
            let vc = ((segue.destination) as! DetailViewController)
            vc.dataModel = self.dataModel
        }
    }

    /* View Life Cycle Method(s) */
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
