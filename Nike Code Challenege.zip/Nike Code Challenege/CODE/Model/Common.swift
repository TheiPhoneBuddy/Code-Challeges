//
//  Common.swift
//  Coding Challenge
//
//  Created by Francis Chan on 2/1/19.
//  Copyright © 2017 TheiPhoneBuddy. All rights reserved.
//

import UIKit

class Common: NSObject {
}
