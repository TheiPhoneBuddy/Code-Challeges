//
//  DataModel.swift
//  Coding Challenge
//
//  Created by Francis Chan on 5/25/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

import UIKit

struct DataModel {
    var id:String = ""
    var artistName:String = ""
    var artworkUrl100:String = ""
    var name:String = ""

    var copyright:String = ""
    var releaseDate:String = ""
    var genre:String = ""
    var url:String = ""
    var image:UIImage?
/*
     "artistName":"Madonna",
     "id":"1459938538",
     "releaseDate":"2019-06-14",
     "name":"Madame X (Deluxe)",
     "kind":"album",
     "copyright":"℗ 2019 Boy Toy, Inc., Exclusively licensed to Live Nation Worldwide, Inc. Exclusively licensed to Interscope Records",
     "artistId":"20044",
     "artistUrl":"https://music.apple.com/us/artist/madonna/20044?app=music",
     "artworkUrl100":"https://is4-ssl.mzstatic.com/image/thumb/Music123/v4/a9/3e/b0/a93eb05e-ffee-be74-8674-9b9006afc555/00602577826078.rgb.jpg/200x200bb.png",
     "genres":[
     {
     "genreId":"14",
     "name":"Pop",
     "url":"https://itunes.apple.com/us/genre/id14"
     },
     {
     "genreId":"34",
     "name":"Music",
     "url":"https://itunes.apple.com/us/genre/id34"
     }
     ],
     "url":"https://music.apple.com/us/album/madame-x-deluxe/1459938538?app=music"
     },
 
 */
}
