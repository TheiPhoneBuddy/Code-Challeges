//
//  DataModel.swift
//  Coding Challenge
//
//  Created by Francis Chan on 5/25/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

import UIKit

struct DataModel {
    var id:String = ""
    var artistName:String = ""
    var artworkUrl100:String = ""
    var name:String = ""

    var copyright:String = ""
    var releaseDate:String = ""
    var genre:String = ""
    var url:String = ""
    var image:UIImage?
}
