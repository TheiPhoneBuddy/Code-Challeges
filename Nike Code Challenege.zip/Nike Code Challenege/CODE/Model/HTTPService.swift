//
//  HTTPService.swift
//  Coding Challenge
//
//  Created by Francis Chan on 5/25/19.
//  Copyright © 2019 TheiPhoneBuddy. All rights reserved.
//

import HTTPManager

class HTTPService: NSObject {
    fileprivate var aryRequests:Array<Dictionary<String,Any>> = []
    fileprivate var aryDataModel:Array<DataModel> = []
    fileprivate var dictPhotos:Dictionary<String,Any>? = [:]

    fileprivate var request:HTTPServiceRequest?
    fileprivate var response:HTTPServiceResponse = HTTPServiceResponse()
    fileprivate var callback:HTTPServiceResponse.callback?

    /* Public Method(s) */
    func makeRequest(_ request:HTTPServiceRequest?,
                      callback:@escaping HTTPServiceResponse.callback) {

        self.request = request
        self.callback = callback
        
        guard self.request!.urlString != nil else {
            self.response.errorMsg = "'urlString' is a required parameter."
            self.executeCallback()
            return
        }
        
        let request: [String: String] = ["urlString": self.request!.urlString!,
                                         "requestID":""]
        
        /*
         "HTTPManager.framework" is a free dynamic network library I developed in swift
         and can be downloaded from my GitHub acct. at:
         
         https://github.com/TheiPhoneBuddy/HTTPManager
         
         "FastFoodApp","TheDailyNewsApp","TheiPhoneBuddy"
         and other apps use this library that is in
         production e.g. App Store & GitHub.
         */
        weak var weakSelf = self
        HTTPManager.getData(request,
                    callback:{[addRequest,
                               getImages](resp:Dictionary<String,Any>?,
                    errorMsg:String?) -> Void in
            
            if( errorMsg != nil){
                weakSelf?.response.errorMsg = errorMsg
                weakSelf?.executeCallback()
            }else{
                /* responseDict */
                let responseDict:Dictionary<String,Any>? = resp?["responseDict"] as? Dictionary<String,Any>
                if responseDict == nil {
                    weakSelf?.response.errorMsg = "'responseDict' missing."
                    weakSelf?.executeCallback()
                    return
                }
                
                /* feed */
                let feed:Dictionary<String,Any>? = responseDict?["feed"] as? Dictionary<String, Any>
                if feed == nil {
                    weakSelf?.response.errorMsg = "'feed' missing."
                    weakSelf?.executeCallback()
                    return
                }

                /* results */
                let results:Array<Any>? = feed?["results"] as? Array<Any>
                if results == nil {
                    weakSelf?.response.errorMsg = "'results' data."
                    weakSelf?.executeCallback()
                    return
                }

                if results?.count == 0 {
                    weakSelf?.response.errorMsg = "No data returned"
                    weakSelf?.executeCallback()
                    return
                }

                for tmp in results!{
                    let dict:Dictionary<String,Any>? = tmp as? Dictionary<String,Any>
                    
                    autoreleasepool{
                        var dataModel:DataModel? = DataModel()
                        
                        /* id */
                        let id:String? = dict?["id"] as? String
                        if let tmp = id {
                            dataModel?.id = tmp
                        }

                        /* artistName */
                        let artistName:String? = dict?["artistName"] as? String
                        if let tmp = artistName {
                            dataModel?.artistName = tmp
                        }

                        /* artworkUrl100 */
                        let artworkUrl100:String? = dict?["artworkUrl100"] as? String
                        if let tmp = artworkUrl100 {
                            dataModel?.artworkUrl100 = tmp
                        }

                        /* name */
                        let name:String? = dict?["name"] as? String
                        if let tmp = name {
                            dataModel?.name = tmp
                        }

                        /* copyright */
                        let copyright:String? = dict?["copyright"] as? String
                        if let tmp = copyright {
                            dataModel?.copyright = tmp
                        }
                        
                        /* releaseDate */
                        let releaseDate:String? = dict?["releaseDate"] as? String
                        if let tmp = releaseDate {
                            dataModel?.releaseDate = tmp
                        }
                        
                        /* url */
                        let url:String? = dict?["url"] as? String
                        if let tmp = url {
                            dataModel?.url = tmp
                        }

                        /* genre */
                        let genres:Array<Any>? = dict?["genres"] as? Array<Any>
                        var genre:String? = ""
                        for tmp in genres! {
                            let dict:Dictionary<String,Any>? = tmp as? Dictionary<String,Any>
                            genre = genre! + " " + ((dict?["name"] as? String)!)

                        }
                        
                        if let tmp = genre {
                            dataModel?.genre = tmp
                        }

                        /* aryDataModel */
                        if let tmp = dataModel {
                           weakSelf?.aryDataModel.append(tmp)
                        }
                        
                        /* Create image download request(s). */
                        if let tmp = dataModel {
                           addRequest(tmp)
                        }
                        dataModel = nil
                        
                    }//autoreleasepool
                }//for
                
               /* Download all images. */
               getImages()

            }//if
                                
        })//HTTPManager
    }
    
    /* Private Method(s) */
    fileprivate func getImages(){
        let request: Dictionary<String,Any> = ["aryRequests": self.aryRequests,
                                               "requestPerBatch":50]
        weak var weakSelf = self
        HTTPManager.makeRequests(request,callback:{[executeCallback](resp:Dictionary<String,Any>?,
            errorMsg:String?) -> Void in
            
            if(errorMsg != nil){
                weakSelf?.response.errorMsg = errorMsg
                weakSelf?.executeCallback()
            }else{
                //let time:String = resp!["time"] as! String
                //print("\n\n" + time + "\n\n")

                weakSelf?.dictPhotos = resp!["data"] as? Dictionary<String,Any>
                executeCallback()
            }
        })
    }

    fileprivate func addRequest(_ dataModel:DataModel){
        let dict: [String: String] = ["urlString":dataModel.artworkUrl100,
                                      "requestID":dataModel.id]
        self.aryRequests.append(dict)
    }

    fileprivate func executeCallback(){
        self.response.aryDataModel = self.aryDataModel
        self.response.dictPhotos = self.dictPhotos!
        if let tmp = self.callback {
           tmp(self.response)
        }
    }
    
    deinit {
        //print("HTTPService:deinit")
    }
}
