//
//  LinearProgressBar.h
//  LinearProgressBar
//
//  Created by Eliel Gordon on 11/13/15.
//  Copyright © 2015 Eliel Gordon. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for LinearProgressBar.
FOUNDATION_EXPORT double LinearProgressBarVersionNumber;

//! Project version string for LinearProgressBar.
FOUNDATION_EXPORT const unsigned char LinearProgressBarVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <LinearProgressBar/PublicHeader.h>


