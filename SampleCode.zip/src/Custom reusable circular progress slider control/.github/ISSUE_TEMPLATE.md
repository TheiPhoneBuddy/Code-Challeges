<!-- Love HGCircularSlider? please consider sponsoring me so I can continue maintaining and evolving all my projects and new ones. 😄 ✨🏎
👉  https://github.com/users/HamzaGhazouani/sponsorship -->
