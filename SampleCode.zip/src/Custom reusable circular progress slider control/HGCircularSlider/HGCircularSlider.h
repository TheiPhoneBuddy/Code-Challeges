//
//  HGCircularSlider.h
//  HGCircularSlider
//
//  Created by Andrzej Michnia on 02.02.2017.
//  Copyright © 2017 intive. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for HGCircularSlider.
FOUNDATION_EXPORT double HGCircularSliderVersionNumber;

//! Project version string for HGCircularSlider.
FOUNDATION_EXPORT const unsigned char HGCircularSliderVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <HGCircularSlider/PublicHeader.h>


