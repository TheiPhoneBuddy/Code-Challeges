//
//  LoyaltyCircularProgressViewController.swift
//  progressBar
//
//  Created by Francis Chan on 2/17/20.
//
//

import UIKit

class LoyaltyCircularProgressViewController: UIViewController {
    @IBOutlet weak var circularProgress: LoyaltyCircularProgressView!
    
    @IBOutlet weak var leftGraph: LoyaltyCircularProgressView!
    @IBOutlet weak var rightGraph: LoyaltyCircularProgressView!

    override func viewDidLoad() {
        super.viewDidLoad()
        initGraphs()
    }
    
    func initGraphs(){
        let gold = UIColor(hex: "#ffe700ff")
        leftGraph.trackingColor = gold ?? UIColor.black
        leftGraph.progressColor = UIColor.purple
        leftGraph.setProgressWithAnimation(duration: 1.0, value: 0.22)
        
        rightGraph.trackingColor = gold ?? UIColor.black
        rightGraph.progressColor = UIColor.purple
        rightGraph.setProgressWithAnimation(duration: 1.0, value: 0.55)
    }
}
