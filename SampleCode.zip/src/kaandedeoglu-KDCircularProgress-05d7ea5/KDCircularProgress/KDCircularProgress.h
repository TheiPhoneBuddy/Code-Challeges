//
//  KDCircularProgress iOS.h
//  KDCircularProgress iOS
//
//  Copyright (c) 2019 Kaan Dedeoglu. All rights reserved.
//
//

#import <UIKit/UIKit.h>

//! Project version number for KDCircularProgress.
FOUNDATION_EXPORT double KDCircularProgressVersionNumber;

//! Project version string for KDCircularProgress.
FOUNDATION_EXPORT const unsigned char KDCircularProgressVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <KDCircularProgress/PublicHeader.h>


