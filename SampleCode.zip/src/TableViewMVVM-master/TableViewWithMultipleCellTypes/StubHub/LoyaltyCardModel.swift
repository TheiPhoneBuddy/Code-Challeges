//
//  LoyaltyCardModel.swift
//  StubHub
//
//  Created by Francis Chan on 2/16/20.
//  
//

import UIKit

struct LoyaltyCardModel {
    var aryCellTypes:[LoyaltyCellType] = []
    var headerText: String = ""
    var subText: String = ""
    var tierText: String = ""
    var buttonText: String = ""    
}
