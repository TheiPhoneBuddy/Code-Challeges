//
//  LoyaltyViewControllerBase.swift
//  StubHub
//
//  Created by Francis Chan on 2/15/20.
//  
//

import UIKit

enum LoyaltyStatus {
    case Awareness
    case Adpotion
    case Engagement
    case Earn
    case Unlock
    case Burn
    case Reset
    case ZeroState
}

enum LoyaltyCellType {
    case HeaderTableViewCell
    case ProgressCircleTableViewCell
    case ProgressBarTableViewCell
    case ButtonTableViewCell
    case ZeroStateTableViewCell
}

class LoyaltyViewControllerBase: UIViewController {
    @IBOutlet weak private var tableView: UITableView?

    var tableViewObject: UITableView {
        get {
            if let tableView = tableView {
               return tableView
            }
            
            return UITableView()
        }
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
