//
//  LoyaltyCardZeroStateViewModel.swift
//
//
//  Created by Francis Chan on 2/16/20.
//  
//

import UIKit

class LoyaltyCardZeroStateViewModel: NSObject {
    var modelData: LoyaltyCardModel {
        get {
            var model:LoyaltyCardModel = LoyaltyCardModel()
            model.aryCellTypes = [LoyaltyCellType.ZeroStateTableViewCell]
            model.buttonText = "Claim your points"

            return model
        }
    }
}
