//
//  LoyaltyCardAwarenessViewController.swift
//
//
//  Created by Francis Chan on 2/16/20.
//
//

import UIKit

class LoyaltyCardAwarenessViewController: LoyaltyViewControllerBase,
                                          LoyaltyCardDelegate {
        var viewModel: LoyaltyCardAwarenessViewModel = LoyaltyCardAwarenessViewModel()
        var tableViewDatasource: LoyaltyCardTableViewDataSource?
        var tableViewDelegate: LoyaltyCardTableViewDelegate?
        
        private func initTableView(){
            self.tableViewDelegate = LoyaltyCardTableViewDelegate(withDelegate: self)
            self.tableViewDatasource = LoyaltyCardTableViewDataSource(withModelData: viewModel.modelData)

            tableViewObject.delegate = self.tableViewDelegate
            tableViewObject.dataSource = self.tableViewDatasource

            //Register cells used by "Awareness" card only.
            tableViewObject.register(LoyaltyHeaderTableViewCell.nib, forCellReuseIdentifier: LoyaltyHeaderTableViewCell.identifier)
            tableViewObject.register(LoyaltyProgressTableViewCell.nib, forCellReuseIdentifier: LoyaltyProgressTableViewCell.identifier)
            tableViewObject.register(LoyaltyButtonTableViewCell.nib, forCellReuseIdentifier: LoyaltyButtonTableViewCell.identifier)
            
//        tableViewObject.register(Loyalty2CircleGraphsTableViewCell.nib, forCellReuseIdentifier: Loyalty2CircleGraphsTableViewCell.identifier)
//        tableViewObject.register(LoyaltyZeroStateTableViewCell.nib, forCellReuseIdentifier: LoyaltyZeroStateTableViewCell.identifier)
        }
        
        //Delegate Mtheod(s)
        func selectedCell(row: Int) {
            print("Row: \(row)")
        }
        
        override func viewDidLoad() {
            super.viewDidLoad()
            initTableView()
        }
}
