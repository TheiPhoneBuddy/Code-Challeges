//
//  LoyaltyCardDelegate.swift
//  StubHub
//
//  Created by Francis Chan on 2/16/20.
//  
//

import UIKit

protocol LoyaltyCardDelegate: class {
   func selectedCell(row: Int)
}
