//
//  LoyaltyCardViewModel.swift
//  TableViewWithMultipleCellTypes
//
//  Created by Francis Chan on 2/15/20.
//  Copyright © 2020 Stanislav Ostrovskiy. All rights reserved.
//

import Foundation

class LoyaltyCardViewModel: NSObject {
    var aryCellTypes: [LoyaltyCellType] = []
    var aryData:[LoyaltyCardModel] = []
    var sampleData: [String] = ["data 0",
                                "data 1",
                                "data 2",
                                "data 3",
                                "data 4"]
    
    init(_ aryCellTypes:[LoyaltyCellType]) {
         self.aryCellTypes = aryCellTypes
    }
    
    var modelData: [LoyaltyCardModel] {
         get {
               buildArray()
               return aryData
        }
    }
    
    var data: [String] {
      get { return sampleData}
    }
    
    func buildArray(){
        
        
        var model:LoyaltyCardModel = LoyaltyCardModel()
        model.cellType = LoyaltyCellType.HeaderCell
        model.headerText = "Loyalty Header"
        
        aryData.append(model)
        
        
    }
}
