//
//  RxSwiftViewController.swift
//  TableViewWithMultipleCellTypes
//
//  Created by Francis Chan on 3/1/20.
/*
 https://engineering.upgrad.com/introduction-to-reactive-programming-using-rxswift-a949b023400d

 https://github.com/ReactiveX/RxSwift/blob/master/Documentation/GettingStarted.md#creating-your-own-observable-aka-observable-sequence
 
 https://www.natashatherobot.com/swift-magic-public-getter-private-setter/

 https://blog.propellerlabs.co/cancelling-asynchronous-tasks-with-rxswift-1ab243dde7a
 
 https://www.raywenderlich.com/2273-swift-functional-programming-tutorial
 
 https://github.com/ReactiveX/RxSwift
 
 https://medium.com/swift-programming/reactive-swift-3b6050375534
 
 
 */

import UIKit
import RxSwift

class RxSwiftViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        //test1()
        //test2()
        //test3()
        //test4()
        test5()
        //testData()
        
        //exit(1)
    }
    
    func testData(){
        getData(request:"zzzz") {(data) in
            DispatchQueue.main.async {
                print(data)
                exit(1)
            }
        }
    }
    
    func getData(request:String,
                 completion: @escaping(_ data:String) -> Void) {
        DispatchQueue.main.asyncAfter(deadline: .now() + 5) {
            completion("getData callback")
        }
    }

    func test5(){
        //let disposeBag = DisposeBag()
        let postsObservable: Observable<[LoyaltyCardType]> = getCard()
        _ =  postsObservable.subscribe(onNext: { loyaltyCard in
            let card:LoyaltyCardType = loyaltyCard[0]
            print(card.str ?? "zzzzz")
        })
    }
/*
     final class MyViewController: UIViewController {
         var subscription: Disposable?
         
         override func viewDidLoad() {
             super.viewDidLoad()
             subscription = theObservable().subscribe(onNext: {
                 // handle your subscription
             })
         }
         
         deinit {
             subscription?.dispose()
         }
     }
     
    postsObservable.subscribe(
    onNext: { loyaltyCard in
        let card:LoyaltyCardType = loyaltyCard[0]
        print(card.str ?? "zzzzz")
    }, onError: { (error) in
        print(error.localizedDescription)
    }, onCompleted: {
        print("Completed Successfully")
    }).disposed(by: disposeBag)
*/
//    func getCard() -> Observable<[LoyaltyCardType]> {
//         return Observable.create({ observer in
//            self.getData(request:"zzzz") {(data) in
//                var card = LoyaltyCardType()
//                card.str = data
//                let cards =  card
//                //observer.on([cards])
//                observer.onNext([cards])
//            }
//            //observer.onCompleted()
//            return Disposables.create()
//         })
//     }

    func getCard() -> Observable<[LoyaltyCardType]> {
         return Observable.create({ observer -> Disposable in
            self.getData(request:"zzzz") {(data) in
                var card = LoyaltyCardType()
                card.str = data
                
                if data == "zzzz" {
                    //observer.onError(Swift.Error())
                } else {
                    let cards =  card
                    observer.onNext([cards])
                    //observer.onCompleted()
                }
            }
            return Disposables.create()
         })
     }
        
    func test4(){
        let counter = myInterval(.milliseconds(100))
        print("Started ----")
        let subscription = counter.subscribe(
            onNext: { n in
                print(n)
        })

        Thread.sleep(forTimeInterval: 0.5)
        subscription.dispose()
        print("Ended ----")
    }
    
    func myInterval(_ interval: DispatchTimeInterval) -> Observable<Int> {
        return Observable.create { observer in
            
            print("Subscribed")
            let timer = DispatchSource.makeTimerSource(queue: DispatchQueue.global())
            timer.schedule(deadline: DispatchTime.now() + interval, repeating: interval)

            let cancel = Disposables.create {
                print("Disposed")
                timer.cancel()
            }

            var next = 0
            timer.setEventHandler {
                if cancel.isDisposed {
                    return
                }
                observer.on(.next(next))
                next += 1
            }
            timer.resume()

            return cancel
        }
    }

    func test1(){
        let disposeBag = DisposeBag()
        
        let observablOfArray = Observable.of(["Ronaldo", "Messi", "Neymar"])
        observablOfArray.subscribe(onNext: { (arr) in
            print(arr)
        }, onError: { (error) in
            print("I will execute if any error Occurs")
        }, onCompleted: {
            print("Completed Successfully")
        }).disposed(by: disposeBag)
    }
    
    func test2(){
        let aDisposableBag = DisposeBag()
        
        let thisIsAnObservableStream = Observable.from([1, 2, 3, 4, 5, 6])
        let subscription = thisIsAnObservableStream.subscribe(
            onNext: {
                print("Next value: \($0)") },
            onError: {
                print("Error: \($0)") },
            onCompleted: {
                print("Completed")
        })
        
        // add the subscription to the disposable bag
        // when the bag is collected, the subscription is disposed
        subscription.disposed(by: aDisposableBag)
        // if you do not use a disposable bag, do not forget this!
        // subscription.dispose()
    }
    
    func test3(){
        let aDisposableBag = DisposeBag()
        
        let thisIsAnObservableStream: Observable = Observable.from([1, 2, 3, 4, 5, 6])
            .observeOn(MainScheduler.instance).map { n in
                print("This is performed on the main scheduler")
        }
        
        let subscription = thisIsAnObservableStream
            .subscribeOn(ConcurrentDispatchQueueScheduler(qos: .background))
            .subscribe(onNext: { event in
                print("Handle \(event) on main thread? \(Thread.isMainThread)")
            }, onError: { print("Error: \($0). On main thread? \(Thread.isMainThread)")
            }, onCompleted: { print("Completed. On main thread? \(Thread.isMainThread)") })
        
        subscription.disposed(by: aDisposableBag)
    }
}
