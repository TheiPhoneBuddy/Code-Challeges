//
//  LoyaltyCardDataSource.swift
//  TableViewWithMultipleCellTypes
//
//  Created by Francis Chan on 3/7/20.
//  Copyright © 2020 Stanislav Ostrovskiy. All rights reserved.
//

import UIKit

class LoyaltyCardDataSource: NSObject {

}
