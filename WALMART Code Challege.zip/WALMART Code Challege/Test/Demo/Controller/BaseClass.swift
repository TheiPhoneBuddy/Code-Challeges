//
//  BaseClass.swift
//  Test
//
//  Created by Francis Chan on 11/5/17.
//  Copyright © 2017 TheiPhoneBuddy. All rights reserved.
//

import UIKit
import HTTPManager

class BaseClass: UITableViewController {

    @IBOutlet var customFooter: CustomFooter!

    var loading = false

    var currentPage:Int = 1
    var recsPerPage:Int = 30
    
    var totalProducts:Int = 0
    var totalProductsPages:Int = 0
    
    /* Store downloaded images */
    var images: Dictionary<String,Any> = [:]
    
    /* Array of Dictionary objects */
    var aryData:Array<Product> = []
    
    /* Dictionary object for details view */
    var detailData:Product?
    
    /* HTTPService Method(s) */
    func getImage(_ indexPath: IndexPath, cell: CustomCell) {
        cell.img.image = nil
        
        /* current row */
        let product:Product = aryData[indexPath.row] as Product
        
        /* requestID */
        let requestID:String? = product.productId
        if requestID == nil {
            return
        }
        
        /* urlString */
        let urlString:String? = product.productImage
        if urlString == nil {
            return
        }
        
        /* Check images dictionary */
        if self.images[requestID!] != nil {
            DispatchQueue.main.async {
                let imgData:Data = self.images[requestID!] as! Data
                cell.img.image = UIImage(data: imgData)
            }
            return
        }
        
        weak var weakSelf = self
        let http:HTTPService = HTTPService()
        http.getImage(urlString!,requestID: requestID!) { (data,errorMsg) in
            if errorMsg == nil {
                DispatchQueue.main.async {
                    weakSelf?.images[requestID!] = data
                    cell.img.image = UIImage(data: data!)
                    print("\(requestID!) - \(urlString!)")
                }
            }else{
                /* Do not show error here because images are continously being downloaded.
                   The "showDialog" displays a modal alert!
                 */
                print(errorMsg!)
            }
        }
    }
    
    func makeRequest(){
        if (!loading) {
            loading = true
            customFooter.isHidden = false
            customFooter.msg.text = "Loading products page " + String(currentPage) + "."
            
            let urlString:String = "https://walmartlabs-test.appspot.com/_ah/api/walmart/v1/walmartproducts/56330880-82c2-47eb-9d5d-03db3a49e3bf/" + String(currentPage) + "/" + String(recsPerPage)
            print(urlString)
            
            weak var weakSelf = self
            let http:HTTPService = HTTPService()
            http.makeRequest(urlString) { (products,errorMsg) in
                if errorMsg == nil{
                    /* Bind to tableview using data from "aryData". "products" will NOT be nil
                       because the HTTPService layer already checked.
                     */
                    for product in products! {
                        weakSelf?.aryData.append(product)
                    }
                                        
                    weakSelf?.currentPage = (weakSelf?.currentPage)! + 1
                    weakSelf?.loading = false
                    
                    DispatchQueue.main.async {
                        weakSelf?.tableView.reloadData()
                        weakSelf?.customFooter.isHidden = true
                    }
                }else{
                    DispatchQueue.main.async {
                        weakSelf?.loading = false
                        weakSelf?.customFooter.isHidden = true
                        weakSelf?.showDialog(errorMsg!)
                    }
                }
            }
        }
    }

    /* Helper Method(s) */
    override func scrollViewDidScroll(_ scrollView: UIScrollView) {
        let currentOffset = scrollView.contentOffset.y
        let maximumOffset = scrollView.contentSize.height - scrollView.frame.size.height
        
        if (maximumOffset - currentOffset) <= 40 {
            makeRequest()
        }
    }
    
    func showDialog(_ message:String){
        let alert = UIAlertController(title: "Alert", message: message, preferredStyle: UIAlertControllerStyle.alert)
        alert.addAction(UIAlertAction(title: "OK", style: UIAlertActionStyle.default, handler: nil))
        self.present(alert, animated: true, completion: nil)
    }

    /* View Life Cycle */
    override func viewDidLoad() {
        super.viewDidLoad()
        customFooter.isHidden = true
        makeRequest()
     }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        self.images.removeAll()
    }
}
