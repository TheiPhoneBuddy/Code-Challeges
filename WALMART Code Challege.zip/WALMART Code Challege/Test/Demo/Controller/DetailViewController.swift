//
//  DetailViewController.swift
//  Test
//
//  Created by Francis Chan on 11/5/17.
//  Copyright © 2017 TheiPhoneBuddy. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

    var detailData:Product?
    var productImage:UIImage?

    @IBOutlet weak var productName: UILabel!
    @IBOutlet weak var longDescription: UITextView!
    @IBOutlet weak var img: UIImageView!
    
    /* View Life Cycle Method(s) */
    override func viewDidLoad() {
        super.viewDidLoad()
        
        let productName:String? = detailData?.productName
        let longDescription:String? = detailData?.longDescription

        self.productName.text = productName
        self.longDescription.text = longDescription

        if productImage != nil {
            img.image = productImage
        }
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
}
