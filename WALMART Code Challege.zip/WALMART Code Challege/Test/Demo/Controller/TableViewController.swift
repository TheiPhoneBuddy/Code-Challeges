//
//  TableViewController.swift
//  Demo
//
//  Created by Francis Chan on 11/5/17.
//  Copyright © 2017 TheiPhoneBuddy. All rights reserved.
//

import UIKit

class TableViewController: BaseClass {
    
    /* View Life Cycle Method(s) */
    override func viewDidLoad() {
        super.viewDidLoad()
        
        tableView.estimatedRowHeight = 94.0
        tableView.rowHeight = UITableViewAutomaticDimension
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
    }
    
    /* Tableview Method(s)*/
    override func numberOfSections(in tableView: UITableView) -> Int {
        return 1
    }
    
    override func tableView(_ tableView: UITableView,
                            numberOfRowsInSection section: Int) -> Int {
        return aryData.count
    }
    
    override func tableView(_ tableView: UITableView,
                            cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let identifierFromStoryboard:String = "CustomCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: identifierFromStoryboard, for: indexPath) as! CustomCell
        
        let product:Product = aryData[indexPath.row] as Product
        
        let name:String? = product.productName
        if name != nil {
            cell.name?.text = name
        }
        
        getImage(indexPath, cell:cell)
        
        return cell
    }
    
    override func tableView(_ tableView: UITableView,
                            didSelectRowAt indexPath: IndexPath){
        
        if loading == true {
            return
        }
        
        detailData = aryData[indexPath.row] as Product
        performSegue(withIdentifier: "showDetail", sender: self)
    }
    
    /* Storyboard Method(s)*/
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "showDetail" {
            let vc = ((segue.destination) as! DetailViewController)
                vc.detailData = detailData
            
            let productId:String? = detailData?.productId
            if productId != nil {
                if self.images[productId!] != nil {
                    let data:Data = self.images[productId!] as! Data
                    vc.productImage = UIImage(data: data)
                }
            }
        }
    }    
}
