//
//  CustomFooter.swift
//  Test
//
//  Created by Francis Chan on 11/5/17.
//  Copyright © 2017 TheiPhoneBuddy. All rights reserved.
//

import UIKit

class CustomFooter: UIView {
    
    @IBOutlet var activityIndicator: UIActivityIndicatorView!
    @IBOutlet var msg: UILabel!
    
    override func awakeFromNib() {
        self.activityIndicator.startAnimating()
    }
}
