//
//  CustomCell.swift
//  Test
//
//  Created by Francis Chan on 11/5/17.
//  Copyright © 2017 TheiPhoneBuddy. All rights reserved.
//

import UIKit

class CustomCell: UITableViewCell {
    
    @IBOutlet weak var name: UILabel!
    @IBOutlet weak var img: UIImageView!
}

