//
//  HTTPService.swift
//  Test
//
//  Created by Francis Chan on 11/5/17.
//  Copyright © 2017 TheiPhoneBuddy. All rights reserved.
//

import UIKit
import HTTPManager

class HTTPService: NSObject {

    func makeRequest(_ urlString:String?,
                     completion: @escaping(_ products:Array<Product>?,
                                           _ errorMsg:String?) -> Void) {
        
        if urlString == nil {
            completion(nil,"'urlString' param cannot be nil!")
            return
        }

        let request: [String: String] = ["urlString": urlString!,
                                         "requestID":""]
        
        /*
         "HTTPManager.framework" is a free dynamic network library I developed in swift
         and can be downloaded from my GitHub acct. at:
         
         https://github.com/TheiPhoneBuddy/HTTPManager
         
         "FastFoodApp","TheDailyNewsApp","TheiPhoneBuddy" and other apps use this library that
         are currently in production e.g. App Store.
         */
        HTTPManager.getData(request,callback:{(resp:Dictionary<String,Any>?,
                                               errorMsg:String?) -> Void in
            
            if((errorMsg) != nil){
                completion(nil,errorMsg)
            }else{
                let responseDict = resp?["responseDict"]
                if((responseDict) != nil){
                    let responseDict:Dictionary<String,Any>? = resp?["responseDict"] as Any as? Dictionary<String, Any>
                    
                    /* Check for nil. */
                    if responseDict == nil {
                        completion(nil,"No response returned.")
                    }else{
                        let aryData:Array<Dictionary<String,Any>>? = responseDict!["products"] as? Array<Dictionary<String,Any>>
                        
                        if aryData == nil || aryData?.count == 0 {
                            completion(nil,"No products returned.")
                        }else{
                        
                            var products:Array<Product>? = []

                            for dict:Dictionary<String,Any> in aryData!{
                                
                                var product:Product? = Product()
                                
                                /* productId */
                                let productId:String? = dict["productId"] as? String
                                if productId != nil {
                                   product?.productId = productId
                                }
                                
                                /* productName */
                                let productName:String? = dict["productName"] as? String
                                if productName != nil {
                                    product?.productName = productName
                                }

                                /* productImage */
                                let productImage:String? = dict["productImage"] as? String
                                if productImage != nil {
                                    product?.productImage = productImage
                                }

                                /* shortDescription */
                                let shortDescription:String? = dict["shortDescription"] as? String
                                if shortDescription != nil {
                                    product?.shortDescription = shortDescription
                                }

                                /* longDescription */
                                let longDescription:String? = dict["longDescription"] as? String
                                if longDescription != nil {
                                    product?.longDescription = longDescription
                                }

                                /* price */
                                let price:String? = dict["price"] as? String
                                if price != nil {
                                    product?.price = price
                                }

                                /* reviewRating */
                                let reviewRating:Int? = dict["reviewRating"] as? Int
                                if reviewRating != nil {
                                    product?.reviewRating = reviewRating
                                }

                                /* reviewCount */
                                let reviewCount:Int? = dict["reviewCount"] as? Int
                                if reviewCount != nil {
                                    product?.reviewCount = reviewCount
                                }

                                /* inStock */
                                let inStock:Bool? = dict["inStock"] as? Bool
                                if inStock != nil {
                                    product?.inStock = inStock
                                }

                                /* Add to array of Product */
                                if product != nil {
                                    products?.append(product!)
                                }
                                product = nil
                            }
                            
                            if products == nil || products?.count == 0 {
                                completion(nil,"No products returned.")
                            }else{
                                completion(products!,nil)
                            }
                        }
                    }
                }else{
                   completion(nil,"Failed to return 'responseDict' from 'HTTPManager'.")
                }
            }
        })
    }
    
    func getImage(_ urlString:String?,
                    requestID:String?,
                   completion:@escaping(_ data:Data?,
                                        _ errorMsg:String?) -> Void) {
        
        if urlString == nil || requestID == nil {
            completion(nil,"Both 'urlString' & 'requestID' params cannot be nil!")
            return
        }
        
        let request: [String: String] = ["urlString":urlString!,
                                         "requestID":requestID!]
        HTTPManager.getData(request,callback:{(resp:Dictionary<String,Any>?,errorMsg:String?) -> Void in
            if((errorMsg) != nil){
                 completion(nil,errorMsg)
            }else{
                let data:Data? = resp?["responseData"] as? Data
                if let tmp = data {
                   completion(tmp,nil)
                }else{
                    completion(nil,"Failed to return image data from 'HTTPManager'.")
                }
             }
        })
    }
 }
