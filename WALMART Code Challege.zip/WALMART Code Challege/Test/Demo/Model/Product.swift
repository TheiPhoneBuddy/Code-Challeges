//
//  Product.swift
//  Test
//
//  Created by Francis Chan on 11/5/17.
//  Copyright © 2017 TheiPhoneBuddy. All rights reserved.
//

import UIKit

struct Product {
    var productId:String?
    var productName:String?
    var productImage:String?
    
    var shortDescription:String?
    var longDescription:String?
    
    var price:String?
    var reviewRating:Int?
    var reviewCount:Int?
    var inStock:Bool?
}
