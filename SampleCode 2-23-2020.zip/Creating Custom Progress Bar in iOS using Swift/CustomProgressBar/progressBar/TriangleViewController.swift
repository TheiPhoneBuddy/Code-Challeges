//
//  TriangleViewController.swift
//  progressBar
//
//  Created by Francis Chan on 2/17/20.
//  Copyright © 2020 ashika shanthi. All rights reserved.
//

import UIKit

class TriangleViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
