//
//  LoyaltyCircularProgressViewController.swift
//  progressBar
//
//  Created by Francis Chan on 2/17/20.
//
//

import UIKit

class LoyaltyCircularProgressViewController: UIViewController,
                                             LoyaltyCircularProgressViewDelegate {
    
    @IBOutlet weak var leftGraph: LoyaltyCircularProgressView!
    @IBOutlet weak var rightGraph: LoyaltyCircularProgressView!

    var leftGraphValue: Float = 0.20
    var rightGraphValue: Float = 1.00

    override func viewDidLoad() {
        super.viewDidLoad()
        initGraphs()
    }
    
    func initGraphs(){
        let gold = UIColor(hex: "#ffe700ff")
        leftGraph.delegate = self
        leftGraph.trackingColor = gold ?? UIColor.black
        leftGraph.progressColor = UIColor.purple
        leftGraph.setProgressWithAnimation(duration: 1.0,
                                           value: leftGraphValue,
                                           uniqueID:123)
 
        rightGraph.delegate = self
        rightGraph.trackingColor = gold ?? UIColor.black
        rightGraph.progressColor = UIColor.purple
        rightGraph.setProgressWithAnimation(duration: 1.0,
                                            value: rightGraphValue,
                                            uniqueID:888)
    }
    
    // LoyaltyCircularProgressViewDelegate delegate method(s)
    func loyaltyAnimationDidStart(_ anim: CAAnimation,uniqueID:Int){
        if leftGraphValue == 1.0 && uniqueID == 123  {
            print("loyaltyAnimationDidStart:",uniqueID)
        }
        
        if rightGraphValue == 1.0  && uniqueID == 888{
            print("loyaltyAnimationDidStart:",uniqueID)
        }
    }
    
    func loyaltyAnimationDidStop(_ anim: CAAnimation, finished flag: Bool,uniqueID:Int){
         if leftGraphValue == 1.0 && uniqueID == 123  {
             print("loyaltyAnimationDidStop:",uniqueID)
         }
         
         if rightGraphValue == 1.0  && uniqueID == 888{
             print("loyaltyAnimationDidStop:",uniqueID)
         }
    }
}
