//
//  LoyaltyCircularProgressView.swift
//  progressBar
//
//  Created by Francis Chan on 2/17/20.
//
//

import UIKit

class LoyaltyCircularProgressView: UIView,CAAnimationDelegate {
    private var uniqueID: Int = 0
    let lineWidth:CGFloat = 30.0

    private var backgroundShapeLayer = CAShapeLayer()
    private var foregroundShapeLayer = CAShapeLayer()
    
    weak var delegate: LoyaltyCircularProgressViewDelegate?

    required init?(coder aDecoder: NSCoder) {
       super.init(coder: aDecoder)
       makeCircularPath()
    }
    
    var progressColor = UIColor.white {
       didSet {
          backgroundShapeLayer.strokeColor = progressColor.cgColor
       }
    }
    
    var trackingColor = UIColor.white {
       didSet {
          foregroundShapeLayer.strokeColor = trackingColor.cgColor
       }
    }
    
    func makeCircularPath() {
       self.backgroundColor = UIColor.clear
       self.layer.cornerRadius = self.frame.size.width/2
       let circlePath = UIBezierPath(arcCenter: CGPoint(x: frame.size.width/2,
                                                        y: frame.size.height/2),
             radius: (frame.size.width - 1.5)/2,
             startAngle: CGFloat(-0.5 * .pi),
             endAngle: CGFloat(1.5 * .pi),
             clockwise: true)
        
       foregroundShapeLayer.path = circlePath.cgPath
       foregroundShapeLayer.fillColor = UIColor.clear.cgColor
       foregroundShapeLayer.strokeColor = trackingColor.cgColor
       foregroundShapeLayer.lineWidth = lineWidth
       foregroundShapeLayer.strokeEnd = 1.0
       layer.addSublayer(foregroundShapeLayer)
        
       backgroundShapeLayer.path = circlePath.cgPath
       backgroundShapeLayer.fillColor = UIColor.clear.cgColor
       backgroundShapeLayer.strokeColor = progressColor.cgColor
       backgroundShapeLayer.lineWidth = lineWidth
       backgroundShapeLayer.strokeEnd = 0.0
       layer.addSublayer(backgroundShapeLayer)
        
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = circlePath.cgPath
        layer.mask = shapeLayer
    }
    
    func setProgressWithAnimation(duration: TimeInterval, value: Float, uniqueID:Int) {
       self.uniqueID = uniqueID
       let animation = CABasicAnimation(keyPath: "strokeEnd")
       animation.delegate = self
       animation.duration = duration
       animation.fromValue = 0
       animation.toValue = value
       animation.timingFunction = CAMediaTimingFunction(name: kCAMediaTimingFunctionLinear)
       backgroundShapeLayer.strokeEnd = CGFloat(value)
       backgroundShapeLayer.add(animation, forKey: "animateprogress")
    }
    
    // CABasicAnimation delegate method(s)
    func animationDidStart(_ anim: CAAnimation){
        delegate?.loyaltyAnimationDidStart(anim,uniqueID:uniqueID)
    }

    func animationDidStop(_ anim: CAAnimation, finished flag: Bool){
        if flag == true {
           delegate?.loyaltyAnimationDidStop(anim,
                                             finished:flag,
                                             uniqueID:uniqueID)
        }
    }
}
