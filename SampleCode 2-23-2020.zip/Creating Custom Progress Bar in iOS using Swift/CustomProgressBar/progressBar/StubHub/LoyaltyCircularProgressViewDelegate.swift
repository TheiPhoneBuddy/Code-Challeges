//
//  LoyaltyCircularProgressViewDelegate.swift
//  progressBar
//
//  Created by Francis Chan on 2/22/20.
//  Copyright © 2020 ashika shanthi. All rights reserved.
//

import UIKit

protocol LoyaltyCircularProgressViewDelegate: class {
    func loyaltyAnimationDidStart(_ anim: CAAnimation,uniqueID:Int);
    func loyaltyAnimationDidStop(_ anim: CAAnimation, finished flag: Bool,uniqueID:Int);
}
