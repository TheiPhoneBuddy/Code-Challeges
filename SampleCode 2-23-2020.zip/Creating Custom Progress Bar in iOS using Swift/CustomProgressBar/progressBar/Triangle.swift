import UIKit

class Triangle: UIView {
    var color: UIColor = .blue
    var firstPointX: CGFloat = 0
    var firstPointY: CGFloat = 0
    var secondPointX: CGFloat = 0.5
    var secondPointY: CGFloat = 1
    var thirdPointX: CGFloat = 1
    var thirdPointY: CGFloat = 0

    override func draw(_ rect: CGRect) {
        rectangle(rect)
        //triangle(rect)
    }
    
    func rectangle(_ rect: CGRect){
        //https://stackoverflow.com/questions/26339943/create-a-uiview-with-only-one-diagonal-side
        // Drawing code
        // Get Height and Width
        //let layerHeight = layer.frame.height
        /*
         CAShapeLayer *layer = [CAShapeLayer layer];

         UIBezierPath *path = [UIBezierPath bezierPath];
         [path moveToPoint:CGPointMake(0, 100)]; // bottom left corner
         [path addLineToPoint:CGPointMake(100, 0)]; // top middle
         [path addLineToPoint:CGPointMake(300, 0)]; // top right corner
         [path addLineToPoint:CGPointMake(300, 100)]; // bottom right corner
         [path closePath];

         layer.path = path.CGPath;
         layer.fillColor = [UIColor blackColor].CGColor;
         layer.strokeColor = nil;

         [theView.layer addSubLayer:layer];
         */
        let layerWidth = layer.frame.width
        // Create Path
        let bezierPath = UIBezierPath()
        //  Points
        let pointA = CGPoint(x: 0, y: 30)
        let pointB = CGPoint(x: 20, y: 0)
        let pointC = CGPoint(x: layerWidth, y: 0)
        let pointD = CGPoint(x: layerWidth, y:30)
        // Draw the path
        bezierPath.move(to: pointA)
        bezierPath.addLine(to: pointB)
        bezierPath.addLine(to: pointC)
        bezierPath.addLine(to: pointD)
        bezierPath.close()
        // Mask to Path
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = bezierPath.cgPath
        layer.mask = shapeLayer
    }
    
    func triangle(_ rect: CGRect){
        let aPath = UIBezierPath()
        
        aPath.move(to: CGPoint(x: self.firstPointX * rect.width, y: self.firstPointY * rect.height))
        aPath.addLine(to: CGPoint(x: self.secondPointX * rect.width, y: self.secondPointY * rect.height))
        aPath.addLine(to: CGPoint(x: self.thirdPointX * rect.width, y: self.thirdPointY * rect.height))
        
        aPath.close()
        self.color.set()
        self.backgroundColor = .clear
        aPath.fill()
        
        let shapeLayer = CAShapeLayer()
        shapeLayer.path = aPath.cgPath
        layer.mask = shapeLayer
    }
}
