//
//  CircularProgressViewController.swift
//  progressBar
//
//  Created by Francis Chan on 2/15/20.
//
//

import UIKit

class CircularProgressViewController: UIViewController {

    @IBOutlet weak var circularProgress: CircularProgressView!
    
    @IBOutlet weak var leftGraph: CircularProgressView!
    @IBOutlet weak var rightGraph: CircularProgressView!

    override func viewDidLoad() {
        super.viewDidLoad()
        //test()
        initGraphs()
    }
    
    func initGraphs(){
        let gold = UIColor(hex: "#ffe700ff")
        leftGraph.trackClr = gold ?? UIColor.black
        leftGraph.progressClr = UIColor.purple
        leftGraph.setProgressWithAnimation(duration: 1.0, value: 0.22)
        
        rightGraph.trackClr = UIColor.cyan
        rightGraph.progressClr = UIColor.purple
        rightGraph.setProgressWithAnimation(duration: 1.0, value: 0.78)
    }
    
    func test(){
         circularProgress.trackClr = UIColor.cyan
         circularProgress.progressClr = UIColor.purple
        
         circularProgress.setProgressWithAnimation(duration: 1.0, value: 0.42)
    }
}
