//
//  MovieInfoTableViewCell.swift
//  MovieBuff
//
//  Created by Mac Tester on 10/8/16.
//  Copyright © 2016 Lunaria Software LLC. All rights reserved.
//

import UIKit
class MovieInfoTableViewCell:UITableViewCell {
    
    @IBOutlet weak var yearLabel: UILabel!
    @IBOutlet weak var titleLabel: UILabel!
    @IBOutlet weak var posterImageView: UIImageView!
}
