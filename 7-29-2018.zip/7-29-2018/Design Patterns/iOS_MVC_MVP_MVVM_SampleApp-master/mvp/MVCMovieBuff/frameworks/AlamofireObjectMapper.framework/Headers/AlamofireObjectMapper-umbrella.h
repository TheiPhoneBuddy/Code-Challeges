#ifdef __OBJC__
#import <UIKit/UIKit.h>
#endif


FOUNDATION_EXPORT double AlamofireObjectMapperVersionNumber;
FOUNDATION_EXPORT const unsigned char AlamofireObjectMapperVersionString[];

