#ifdef __OBJC__
#import <UIKit/UIKit.h>
#endif


FOUNDATION_EXPORT double AlamofireVersionNumber;
FOUNDATION_EXPORT const unsigned char AlamofireVersionString[];

