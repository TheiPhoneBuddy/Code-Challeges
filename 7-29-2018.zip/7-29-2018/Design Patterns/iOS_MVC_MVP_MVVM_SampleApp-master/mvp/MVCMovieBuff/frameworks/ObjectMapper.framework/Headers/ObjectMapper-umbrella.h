#ifdef __OBJC__
#import <UIKit/UIKit.h>
#endif


FOUNDATION_EXPORT double ObjectMapperVersionNumber;
FOUNDATION_EXPORT const unsigned char ObjectMapperVersionString[];

