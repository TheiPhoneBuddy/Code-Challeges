import Foundation

struct User {
    let firstName: String
    let lastName: String
    let email: String
    let age: Int
}
