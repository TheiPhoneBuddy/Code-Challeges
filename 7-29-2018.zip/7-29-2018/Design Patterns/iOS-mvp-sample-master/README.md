# iOS-mvp-sample
A simple example that describes how Model-View-Presenter MVP could be used in iOS apps. More details are described in this article http://iyadagha.com/using-mvp-ios-swift/
