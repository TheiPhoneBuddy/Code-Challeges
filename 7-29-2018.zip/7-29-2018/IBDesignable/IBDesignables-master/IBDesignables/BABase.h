//
//  BABase.h
//  IBDesignables
//
//  Created by Francis Chan on 7/25/18.
//  Copyright © 2018 Pantech. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BABase : UIView

@end
