//
//  BABase.m
//  IBDesignables
//
//  Created by Francis Chan on 7/25/18.
//  Copyright © 2018 Pantech. All rights reserved.
//

#import "BABase.h"

@implementation BABase

@end
