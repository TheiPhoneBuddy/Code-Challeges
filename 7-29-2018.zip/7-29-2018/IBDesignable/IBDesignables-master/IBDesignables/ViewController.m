//
//  ViewController.m
//  IBDesignables
//
//  Created by MilanPanchal on 17/05/15.
//  Copyright (c) 2015 Pantech. All rights reserved.
//

#import "ViewController.h"
#import "SAMCustomView.h"

@interface ViewController ()

@property (weak, nonatomic) IBOutlet SAMCustomView *customView;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.customView.backgroundColor = [UIColor redColor];
    self.customView.borderWidth = 10;
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
@end
