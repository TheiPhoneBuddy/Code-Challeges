
IBDesignables
=====

A sample app that demonstrate use of IBDesignable and IBInspectable attributes in Xcode 6. [Click here](https://techfuzionwithsam.wordpress.com/2015/05/18/xcode6-ibdesignable-and-ibinspectable-with-objective-c/) for the blog post this project is based on.



## Screenshots:

![ScreenShot](https://raw.github.com/milanpanchal/IBDesignables/master/Screenshots/screenshot1.png)


## Contact:


Follow me on 

1. **Twitter** ([@milan_panchal24](https://twitter.com/milan_panchal24))

2. **Github** ([/milanpanchal](https://github.com/milanpanchal/))

3. [https://techfuzionwithsam.wordpress.com/](https://techfuzionwithsam.wordpress.com/)



## License:

This Project is available under the MIT license.


**Free Software, Hell Yeah!**

[2]:http://mobile.tutsplus.com/tutorials/iphone/applying-image-filters-with-gpuimage/
