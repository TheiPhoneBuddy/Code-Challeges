//
//  AppDelegate.swift
//  TableViewBackgroundImage
//
//  Created by Jeff Kereakoglow on 9/15/15.
//  Copyright © 2015 Alexis Digital. All rights reserved.
//

import UIKit

@UIApplicationMain class AppDelegate: UIResponder, UIApplicationDelegate {
  var window: UIWindow?
}
