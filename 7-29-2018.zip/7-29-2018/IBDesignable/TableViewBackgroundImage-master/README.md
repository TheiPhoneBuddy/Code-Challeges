# Table view image background
An example app showing how to create a table view with a statib background image. This project creates and `@IBDesignable` for the table view making it easy for you to set the background image in Storyboard Builder.

<img src="https://raw.githubusercontent.com/jkereako/TableViewBackgroundImage/master/Images/screen-cap.png" alt="Table view background image" width="320" height="568" />

# Credit
Image: [Freer Slacker][slacker]

IBDesignable: [Aaron on Stack Overflow][so]

[slacker]: https://www.asia.si.edu/collections/wallpaper/
[so]: http://stackoverflow.com/questions/5825397/uitableview-background-image#32215518
