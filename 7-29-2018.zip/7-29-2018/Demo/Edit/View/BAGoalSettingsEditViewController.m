//
//  BAGoalSettingsEditViewController.m
//  Demo
//
//  Created by Francis Chan on 7/29/18.
//  Copyright © 2018 TheiPhoneBuddy. All rights reserved.
//

#import "BAGoalSettingsEditViewController.h"

@interface BAGoalSettingsEditViewController ()

@end

@implementation BAGoalSettingsEditViewController

- (void)viewDidLoad {
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
}
@end
