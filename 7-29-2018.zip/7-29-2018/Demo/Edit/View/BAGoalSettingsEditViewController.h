//
//  BAGoalSettingsEditViewController.h
//  Demo
//
//  Created by Francis Chan on 7/29/18.
//  Copyright © 2018 TheiPhoneBuddy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BAGoalSettingsEditViewController : UIViewController

@end
