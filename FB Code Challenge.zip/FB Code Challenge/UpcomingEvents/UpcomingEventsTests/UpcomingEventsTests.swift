//
//  UpcomingEventsTests.swift
//  UpcomingEventsTests
//
//  Created by Francis Chan on 3/24/20.
//  Copyright © 2020 TheiPhoneBuddy. All rights reserved.
//

import XCTest

@testable import UpcomingEvents

class UpcomingEventsTests: XCTestCase,EventsPresenterDelegate {
    let expectation_MakeRequest = XCTestExpectation(description: "MakeRequest")
    let expectation_BadFileName = XCTestExpectation(description: "BadFileName")

    override func setUp() {}

    override func tearDown() {}

    //EventsPresenter Delegate Method(s)
    func didMakeRequestSuccess(){
        expectation_MakeRequest.fulfill()
        print("MakeRequest completed sucessfully!")
    }
    
    func didMakeRequestFailed(_ errorMsg:String){
        expectation_BadFileName.fulfill()
        XCTAssertNotNil(errorMsg, "Error.")
    }

    //Use test cases
    func testMakeRequest(){
        let obj:EventsPresenter = EventsPresenter()
        obj.delegate = self
        obj.makeRequest()
                
        wait(for: [expectation_MakeRequest], timeout: 5.0)
    }
    
    func testBadFileName(){
        let obj:EventsPresenter = EventsPresenter()
        obj.delegate = self
        obj.makeRequest("BadFileName")

        wait(for: [expectation_BadFileName], timeout: 5.0)
    }
}
