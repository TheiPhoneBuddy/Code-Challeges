//
//  Common.swift
//  UpcomingEvents
//
//  Created by Francis Chan on 3/24/20.
//  Copyright © 2020 TheiPhoneBuddy. All rights reserved.
//

import UIKit

class Common: NSObject {
    
    static func getPathToFile(_ fileName:String,
                       fileExtension:String?) -> String {
        var pathToFile:String = ""
        var withExtension:String = "json"
        
        if let fileExtension =  fileExtension {
           withExtension = fileExtension
        }
        
        let url:URL? = Bundle.main.url(forResource: fileName,
                                       withExtension: withExtension)
        if let url = url {
           pathToFile = url.absoluteString
        }
        
        return pathToFile
    }
    
    static func convertDateToString(_ date:Date) -> String? {
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MMMM dd, hh:mm a"
        dateFormatter.timeZone = NSTimeZone(name: "UTC")! as TimeZone
        let str:String? = dateFormatter.string(from: date)
        
        return str
    }
    
    static func convertStringToDate(_ str:String) -> Date? {
        let dateFormatter = DateFormatter()
            dateFormatter.dateFormat = "MMMM dd, yyyy hh:mm a"
            dateFormatter.calendar = Calendar(identifier: .iso8601)
            dateFormatter.timeZone = TimeZone(secondsFromGMT: 0)
            dateFormatter.locale = Locale(identifier: "en_US_POSIX")
        let date:Date? = dateFormatter.date(from: str)

        return date
    }
}

extension Date {
   public static func <(a: Date, b: Date) -> Bool{
        return a.compare(b) == ComparisonResult.orderedAscending
    }
   public static func ==(a: Date, b: Date) -> Bool {
        return a.compare(b) == ComparisonResult.orderedSame
    }
}
