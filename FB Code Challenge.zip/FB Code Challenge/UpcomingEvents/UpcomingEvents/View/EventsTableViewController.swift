//
//  EventsTableViewController.swift
//  UpcomingEvents
//
//  Created by Francis Chan on 3/23/20.
//  Copyright © 2020 TheiPhoneBuddy. All rights reserved.
//

import UIKit

class EventsTableViewController: UITableViewController,
                                 EventsPresenterDelegate {
    
    var presenter:EventsPresenter = EventsPresenter()

    //EventsPresenter Delegate Method(s)
    func didMakeRequestSuccess(){
        weak var weakSelf = self
        DispatchQueue.main.async {
           weakSelf?.tableView.reloadData()
        }
    }
    
    func didMakeRequestFailed(_ errorMsg:String){
        weak var weakSelf = self
        DispatchQueue.main.async {
            weakSelf?.displayAlert("", message: errorMsg,vc:self)
        }
    }

    //TableView Method(s)
    override func numberOfSections(in tableView: UITableView) -> Int {
        return presenter.getSectionCount()
    }

    override func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return presenter.getCount()
    }

    override func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        let identifierFromStoryboard:String = "CustomCell"
        let cell = tableView.dequeueReusableCell(withIdentifier: identifierFromStoryboard, for: indexPath) as! CustomCell
        
        let dataModel:DataModel = presenter.getDataModel(indexPath.row)
        cell.title.text = dataModel.title
        cell.start.text = Common.convertDateToString(dataModel.start)
        cell.end.text = Common.convertDateToString(dataModel.end)
        
        if presenter.eventsData(indexPath.row) == true {
           cell.conflict.isHidden = false
        } else {
           cell.conflict.isHidden = true
        }
        
        return cell
    }
    
    //View Life Cycle Method(s)
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter.delegate = self
        presenter.makeRequest()
    }
    
    //Helper Method(s)
    func displayAlert(_ title:String, message:String, vc:UIViewController){
        let alert:UIAlertController = UIAlertController(title: title,
                                                        message: message,
                                                        preferredStyle: UIAlertController.Style.alert)
        alert.addAction(UIAlertAction(title: "OK",
                                      style: UIAlertAction.Style.default,
                                      handler: nil))
        vc.present(alert, animated: true, completion: nil)
    }
}
