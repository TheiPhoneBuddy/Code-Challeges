//
//  ViewController.swift
//  UpcomingEvents
//
//  Created by Francis Chan on 3/23/20.
//  Copyright © 2020 TheiPhoneBuddy. All rights reserved.
//

import UIKit

class ViewController: UIViewController {
    override func viewDidLoad() {
        super.viewDidLoad()
    }
}
