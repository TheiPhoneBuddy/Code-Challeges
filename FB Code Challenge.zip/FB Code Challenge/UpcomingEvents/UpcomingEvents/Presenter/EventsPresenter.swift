//
//  EventsPresenter.swift
//  UpcomingEvents
//
//  Created by Francis Chan on 3/24/20.
//  Copyright © 2020 TheiPhoneBuddy. All rights reserved.
//

import Foundation

protocol EventsPresenterDelegate:class {
    func didMakeRequestSuccess()
    func didMakeRequestFailed(_ errorMsg:String)
}

class EventsPresenter: NSObject {
    private var aryDataModel:Array<DataModel> = []
    weak var delegate: EventsPresenterDelegate?

    //Public Method(s)
    func makeRequest(_ fileName:String = "mock"){
        let url = Common.getPathToFile(fileName,fileExtension:"json")
        let request: String = url
        getData(request:request) {[parseData](data) in
            parseData(data)
        }
    }
    
    func getSectionCount() -> Int{
        return 1
    }

    func getCount() -> Int{
        return self.aryDataModel.count
    }

    func getDataModel(_ i:Int) -> DataModel{
        return aryDataModel[i]
    }

    func eventsData(_ index:Int) -> Bool {
        let dataModel:DataModel = aryDataModel[index]
        
        for (i,_) in aryDataModel.enumerated() {
            if i == index {
                continue
            }
            
            if checkForConflict(i,dataModel:dataModel) == true {
                return true
            }
        }
        
        return false
    }

    //Private Method(s)
    fileprivate func getData(request:String, completion: @escaping(_ data:Data) -> Void) {
        let config = URLSessionConfiguration.default
        let session = URLSession(configuration: config)
        
        if let url:URL = URL(string: request) {
            weak var weakSelf = self
            let task = session.dataTask(with: url, completionHandler:{
                (data, response, error) in
                if error != nil {
                   weakSelf?.delegate?.didMakeRequestFailed(error?.localizedDescription ?? "Error")
                } else {
                    completion(data!)
                }
            })
            task.resume()
        } else {
            delegate?.didMakeRequestFailed("Invalid url!")
        }
    }
    
    fileprivate func checkForConflict(_ i:Int,dataModel:DataModel) -> Bool {
        if dataModel.start < aryDataModel[i].end &&
           aryDataModel[i].start < dataModel.end {
           return true
        } else {
           return false
        }
    }
        
    fileprivate func parseData(_ data:Data!) {
        do {
            let decoder = JSONDecoder()
                decoder.dateDecodingStrategy = .iso8601
            
            let dateFormatter = DateFormatter()
                dateFormatter.dateFormat = "MMMM dd, yyyy hh:mm a"
                dateFormatter.calendar = Calendar(identifier: .iso8601)
                dateFormatter.timeZone = TimeZone(secondsFromGMT: 0)
                dateFormatter.locale = Locale(identifier: "en_US_POSIX")
            
                decoder.dateDecodingStrategy = .formatted(dateFormatter)

            let aryData:Array<DataModel>? = try decoder.decode([DataModel].self,
                                                                     from:data)
                if let aryData = aryData {
                   aryDataModel = aryData
                   aryDataModel = aryDataModel.sorted(by: {$0.start < $1.start })
                   delegate?.didMakeRequestSuccess()
                } else {
                    delegate?.didMakeRequestFailed("Invalid json!")
                }//if
        } catch {
            delegate?.didMakeRequestFailed("Parse error!")
        }//do
    }
}
