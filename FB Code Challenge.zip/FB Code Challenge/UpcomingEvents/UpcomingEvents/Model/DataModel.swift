//
//  DataModel.swift
//  UpcomingEvents
//
//  Created by Francis Chan on 3/23/20.
//  Copyright © 2020 TheiPhoneBuddy. All rights reserved.
//

import Foundation

struct DataModel: Codable {
    var title:String?
    var start:Date = Date()
    var end:Date = Date()
}
